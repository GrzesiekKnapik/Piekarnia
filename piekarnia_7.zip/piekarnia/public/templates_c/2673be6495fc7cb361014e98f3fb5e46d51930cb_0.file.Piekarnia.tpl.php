<?php
/* Smarty version 4.1.0, created on 2022-06-03 11:58:30
  from 'C:\Users\Sony_PC\Desktop\xamp_\htdocs\piekarnia\app\views\Piekarnia.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_6299db4630ce41_66839158',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2673be6495fc7cb361014e98f3fb5e46d51930cb' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\xamp_\\htdocs\\piekarnia\\app\\views\\Piekarnia.tpl',
      1 => 1654250307,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6299db4630ce41_66839158 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<!DOCTYPE HTML>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="pl" lang="pl">

<head>
	<meta charset="utf-8"/>
	<title>Hello World | Amelia framework</title>
</head>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_12315951526299db462d9c32_28117843', 'navigation');
?>





<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_3421400836299db462db2c3_21015795', 'header');
?>

    
    
    
    
       
    
    
<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_16628638346299db462dc4a8_47572981', 'content');
?>


</html><?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main_1.tpl");
}
/* {block 'navigation'} */
class Block_12315951526299db462d9c32_28117843 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navigation' => 
  array (
    0 => 'Block_12315951526299db462d9c32_28117843',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container px-4 px-lg-5">
                <a class="navbar-brand" href="#!">Start Bootstrap</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                        <li class="nav-item"><a class="nav-link active" aria-current="page" href="#!">Home</a></li>
                        <li class="nav-item"><a class="nav-link" href="#!">About</a></li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Shop</a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="#!">All Products</a></li>
                                <li><hr class="dropdown-divider" /></li>
                                <li><a class="dropdown-item" href="#!">Popular Items</a></li>
                                <li><a class="dropdown-item" href="#!">New Arrivals</a></li>
                            </ul>
                        </li>
                    </ul>
                    <form class="d-flex">
                        <button class="btn btn-outline-dark" type="submit">
                            <i class="bi-cart-fill me-1"></i>
                            Cart
                            <span class="badge bg-dark text-white ms-1 rounded-pill">0</span>
                        </button>
                    </form>
                </div>
            </div>
        </nav>
<?php
}
}
/* {/block 'navigation'} */
/* {block 'header'} */
class Block_3421400836299db462db2c3_21015795 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'header' => 
  array (
    0 => 'Block_3421400836299db462db2c3_21015795',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<header class="bg-dark py-1">
            <div class="container px-4 px-lg-5 my-5">
                <div class="text-center text-white">
                    <h1 class="display-4 fw-bolder">Pod kłosem</h1>
                    <p class="lead fw-normal text-white-50 mb-0">Witamy w naszej piekarni.</p>
                    <p class="lead fw-normal text-white-50 mb-0">Prosimy się zalogować.</p>
                </div>
            </div>
        </header>
<?php
}
}
/* {/block 'header'} */
/* {block 'content'} */
class Block_16628638346299db462dc4a8_47572981 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_16628638346299db462dc4a8_47572981',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    
    <body class="tloBlur">
    
    
  <div class="pure-menu pure-menu-horizontal bottom-margin">
	<a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
logout"  class="pure-menu-heading pure-menu-link">wyloguj</a>
</div>

<div class="pure-menu pure-menu-horizontal bottom-margin">
	<a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
db"  class="pure-menu-heading pure-menu-link">historia</a>
</div>

        
    
        


<!--<?php if (\core\RoleUtils::inRole('admin')) {?> 
<a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
history"  class="pure-menu-heading pure-menu-link">Historia z modyfikacją(baza)</a>    
    <?php }?>

-->

<!-- Section-->
        
            
            <section class="py-5 ">
                <div class="container px-4 px-lg-5 mt-5">
                <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['data_items']->value, 't');
$_smarty_tpl->tpl_vars['t']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['t']->value) {
$_smarty_tpl->tpl_vars['t']->do_else = false;
?>
                <form method="post" action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
piekarnia/<?php echo $_smarty_tpl->tpl_vars['t']->value['name'];?>
">
            
                    
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Product image-->
                            <img class="card-img-top" src="http://localhost/piekarnia/public/img_products/<?php echo $_smarty_tpl->tpl_vars['t']->value["name"];?>
.jpg"  width="450px" height="300px"/>
                            <!-- Product details-->
                            <div class="card-body p-4 tloDlaProdukow">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <input type="hidden" name="hidden_id" value="<?php echo $_smarty_tpl->tpl_vars['t']->value["id_products"];?>
" />
                               <input type="hidden" name="hidden_name" value="<?php echo $_smarty_tpl->tpl_vars['t']->value["name"];?>
" />  
                               <input type="hidden" name="hidden_price" value="<?php echo $_smarty_tpl->tpl_vars['t']->value["price"];?>
" />  
                                    <h5 class="fw-bolder"><?php echo $_smarty_tpl->tpl_vars['t']->value['name'];?>
</h5>
                                    <!-- Product price-->
                                    $<?php echo $_smarty_tpl->tpl_vars['t']->value["price"];?>

                                    <input type="text" name="quantity" class="form-control" value="1" /> 
                                    
                                </div>
                            
                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent centrowanie">
                                 <input type="submit" name="add_to_cart" style="margin-top:5px;" class="btn btn-success" value="Add to Cart" />  
                            </div>
                            </div>
                        </div>
                    </div>
                    </form>
                 <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                </div>
            </div>
                
                                     
        </section>
               
                
                
<?php if (!empty($_smarty_tpl->tpl_vars['shopping_cart']->value)) {?> 
    <!--
 <table>   
 <thead>
	<tr>
		<th>index:</th>
		<th>Nazwa:</th>
		<th>Cena:</th>
                <th>Ilosć:</th>
		<th>Id:</th>
       
	
	</tr>
</thead>
<tbody>       
      
        
<tbody> 
    
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['shopping_cart']->value, 't', false, 'v');
$_smarty_tpl->tpl_vars['t']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['v']->value => $_smarty_tpl->tpl_vars['t']->value) {
$_smarty_tpl->tpl_vars['t']->do_else = false;
?>
<tr><td><?php echo $_smarty_tpl->tpl_vars['v']->value;?>
</td><td><?php echo $_smarty_tpl->tpl_vars['t']->value['item_name'];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['t']->value['item_price'];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['t']->value['item_quantity'];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['t']->value['item_id'];?>
</td><td><a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
delete/<?php echo $_smarty_tpl->tpl_vars['t']->value['item_id'];?>
"<span class="text-danger">Remove<?php echo $_smarty_tpl->tpl_vars['t']->value['item_name'];?>
</span></a></td></tr>   
<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
Total: <?php echo $_smarty_tpl->tpl_vars['total']->value;?>



<a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
orderFin"  class="pure-menu-heading pure-menu-link">Zamów</a>
</tbody>




</table>
-->


//////////
<table class="table background" style="width:40%"> 
  <thead>
    <tr>
      
      <th scope="col">Nazwa</th>
      <th scope="col">Cena</th>
      <th scope="col">Ilość</th>
     
    </tr>
  </thead>
    
  <tbody>
      
      <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['shopping_cart']->value, 't', false, 'v');
$_smarty_tpl->tpl_vars['t']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['v']->value => $_smarty_tpl->tpl_vars['t']->value) {
$_smarty_tpl->tpl_vars['t']->do_else = false;
?>
<tr><td><?php echo $_smarty_tpl->tpl_vars['t']->value['item_name'];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['t']->value['item_price'];?>
$</td><td>x<?php echo $_smarty_tpl->tpl_vars['t']->value['item_quantity'];?>
</td><div class="card-footer p-4 pt-0 border-top-0 bg-transparent centrowanie"><td><a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
delete/<?php echo $_smarty_tpl->tpl_vars['t']->value['item_id'];?>
"<span class="btnt btn-successt">Usuń <?php echo $_smarty_tpl->tpl_vars['t']->value['item_name'];?>
</span></a></td></div></tr>   
<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
   
    <tr>
        <th scope="row">Total</th>
     
      <td><?php echo $_smarty_tpl->tpl_vars['total']->value;?>
$</td
     
               
      
     
          <div class=" pt-0 border-top-0 bg-transparent">
              <td>
    <div><a class=" p-1 btn-outline-dark " href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
orderFin" >Zamów</a></div>
	<td>
</div>
     
    </tr>
  </tbody>
</table>

/////////
<?php }?>
                              
            
    






 </body>
  

<?php
}
}
/* {/block 'content'} */
}
