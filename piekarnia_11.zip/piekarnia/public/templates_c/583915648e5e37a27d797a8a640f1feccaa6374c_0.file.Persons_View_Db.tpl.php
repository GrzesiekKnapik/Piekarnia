<?php
/* Smarty version 4.1.0, created on 2022-06-10 10:49:26
  from 'C:\Users\Sony_PC\Desktop\xamp_\htdocs\piekarnia\app\views\Persons_View_Db.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_62a3059683d9c1_16983127',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '583915648e5e37a27d797a8a640f1feccaa6374c' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\xamp_\\htdocs\\piekarnia\\app\\views\\Persons_View_Db.tpl',
      1 => 1654850964,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62a3059683d9c1_16983127 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_88547144162a30596817d33_29614591', 'navigation');
?>




<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_163570978562a305968261d1_74015510', 'header');
?>




<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_191240492062a30596827397_00632529', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "main_2.tpl");
}
/* {block 'navigation'} */
class Block_88547144162a30596817d33_29614591 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navigation' => 
  array (
    0 => 'Block_88547144162a30596817d33_29614591',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container px-4 px-lg-5">
                <a class="navbar-brand" href="#!">Start Bootstrap</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                        <li class="nav-item"><a class="nav-link active" aria-current="page" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
logout">Wyloguj</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
piekarnia">Piekarnia</a></li>
                        
                        <?php if (\core\RoleUtils::inRole("pracownik")) {?> 
                        <li class="nav-item"><a class="nav-link" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
dbProducts">Edycja produktów</a></li>
                        <?php }?>
                              
                    </ul>
                    
                </div>
            </div>
        </nav>
<?php
}
}
/* {/block 'navigation'} */
/* {block 'header'} */
class Block_163570978562a305968261d1_74015510 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'header' => 
  array (
    0 => 'Block_163570978562a305968261d1_74015510',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<header class="bg-dark py-1">
            <div class="container px-4 px-lg-5 my-5">
                <div class="text-center text-white">
                    <h1 class="display-4 fw-bolder">Pod kłosem</h1>
                    <p class="lead fw-normal text-white-50 mb-0">Historia.</p>

                </div>
            </div>
        </header>
<?php
}
}
/* {/block 'header'} */
/* {block 'content'} */
class Block_191240492062a30596827397_00632529 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_191240492062a30596827397_00632529',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>





<h1> Osoby w bazie: </h1>
<div class="mb-3"><a class=" p-1 btn-outline-dark " href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
search" >Wyszukaj</a></div>

<table class="table background" style="width:40%"> 
  <thead>
    <tr>
      
      <th>Id osoby</th>
                <th>Imie</th>
                <th>Nazwisko</th>
                <?php if (\core\RoleUtils::inRole("admin")) {?>
                <th>Numer loginu</th>
		<th>Rola</th>
                <?php }?>
      
     
    </tr>
  </thead>
    
  <tbody>
      
      <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['data']->value, 't', false, 'v');
$_smarty_tpl->tpl_vars['t']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['v']->value => $_smarty_tpl->tpl_vars['t']->value) {
$_smarty_tpl->tpl_vars['t']->do_else = false;
?>
<tr><td><?php echo $_smarty_tpl->tpl_vars['t']->value['id_person'];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['t']->value['name'];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['t']->value['surname'];?>
</td><?php if (\core\RoleUtils::inRole("admin")) {?><td><?php echo $_smarty_tpl->tpl_vars['t']->value['number_login'];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['t']->value['role_id_role'];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['t']->value['type_role'];?>
</td><td><a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
editRole/<?php echo $_smarty_tpl->tpl_vars['t']->value['id_person'];?>
"<span class="btnt btn-primary">Edytuj</span></a></td><?php }?></tr>   
<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
   
    
  </tbody>
</table>



       
             
<?php
}
}
/* {/block 'content'} */
}
