<?php
/* Smarty version 4.1.0, created on 2022-06-10 00:06:04
  from 'C:\Users\Sony_PC\Desktop\xamp_\htdocs\piekarnia\app\views\templates\main_2.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_62a26ecc0ffe69_99803291',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7fbc83179a5e03d4504eace5a5e9d2558ee8ed57' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\xamp_\\htdocs\\piekarnia\\app\\views\\templates\\main_2.tpl',
      1 => 1654812360,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62a26ecc0ffe69_99803291 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>
<!doctype html>
<html lang="pl">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	
	<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        
        <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/css/styles.css">	
        
        <link rel="stylesheet" href="https://unpkg.com/purecss@0.6.2/build/pure-min.css" integrity="sha384-UQiGfs9ICog+LwheBSRCt1o5cbyKIHbwjWscjemyBMT9YCUMZffs6UqUTd0hObXD" crossorigin="anonymous">
        <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/css/style.css">	
        
</head>
<body>

<div class="navigation">
	<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_206675067562a26ecc0e67d7_61771454', 'navigation');
?>

</div>    
    
    
    
<div class="header">
	<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_90197119162a26ecc0e7f27_80473096', 'header');
?>

</div>

<div class="content ogólny">
<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_122224823862a26ecc0e90f8_08257912', 'content');
?>








<?php if ($_smarty_tpl->tpl_vars['msgs']->value->isMessage()) {?>

	
	<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getMessages(), 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
	<li class="msg <?php if ($_smarty_tpl->tpl_vars['msg']->value->isError()) {?>error<?php }?> <?php if ($_smarty_tpl->tpl_vars['msg']->value->isWarning()) {?>warning<?php }?> <?php if ($_smarty_tpl->tpl_vars['msg']->value->isInfo()) {?>info<?php }?>"><?php echo $_smarty_tpl->tpl_vars['msg']->value->text;?>
</li>
	<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
	
        &emsp;
<?php }?>







</div><!-- content -->


<div class="footer">
    <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_157269667762a26ecc0fe952_13442294', 'footer');
?>


</div>    

   

</body>
</html>

<?php }
/* {block 'navigation'} */
class Block_206675067562a26ecc0e67d7_61771454 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navigation' => 
  array (
    0 => 'Block_206675067562a26ecc0e67d7_61771454',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 Domyślna treść zawartości .... <?php
}
}
/* {/block 'navigation'} */
/* {block 'header'} */
class Block_90197119162a26ecc0e7f27_80473096 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'header' => 
  array (
    0 => 'Block_90197119162a26ecc0e7f27_80473096',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 Domyślna treść zawartości .... <?php
}
}
/* {/block 'header'} */
/* {block 'content'} */
class Block_122224823862a26ecc0e90f8_08257912 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_122224823862a26ecc0e90f8_08257912',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 Domyślna treść zawartości .... <?php
}
}
/* {/block 'content'} */
/* {block 'footer'} */
class Block_157269667762a26ecc0fe952_13442294 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_157269667762a26ecc0fe952_13442294',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 <footer class="py-5 bg-dark">
            <div class="container"><p class="m-0 text-center text-white">Copyright &copy; Your Website 2022</p></div>
        </footer> <?php
}
}
/* {/block 'footer'} */
}
