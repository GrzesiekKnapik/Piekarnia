<?php

namespace app\controllers;

use core\App;
use core\Utils;
use core\RoleUtils;
use core\ParamUtils;
use core\Message;
use app\forms\PersonEditForm;
use core\Validator;



class DbHistory
{
//zmienic na private te funkcje jedną!

    private $role;
    private $variable;
    private $form;
    private $id_orders;
    
    
     public function __construct() {
        //stworzenie potrzebnych obiektów
        $this->form = new PersonEditForm();
    }

     
    
    public function action_showDb(){
        
        $data = App::getDB()->select("orders_products",
            [
            "[><]orders" => ["orders_id_orders" => "id_orders"],
        "[><]products " => ["products_id_products" => "id_products"],
              "[><]person " => ["orders.person_id_person" => "id_person"], 
                // "[><]role" => ["person.role_id_role" => "id_role",
        ], [
           
            "orders.id_orders", "id_orders", "date_orders",
            "orders.person_id_person",
            "products_id_products",
            "quantity",
            "products.name(ProductName)",
            "products.price",
            "total",
            "id_person",
            "person.name(PersonName)",
            "person.surname",
            "orders_id_orders",
           // "role.type_role",
            
            
            
            
             
            ] ,["ORDER" => "orders_id_orders", "ORDER"=>["orders_id_orders" => "DESC"],],);
        
        
        
        
        App::getSmarty()->assign('data', $data);
    }
    ////
    public function validateSearch(){
        
        
        $this->id_orders = ParamUtils::getFromRequest('id_orders');
        
        if($this->id_orders != "")
        {
           return true; 
        }else{
            App::getSmarty()->display('SearchId.tpl');
            return false;
        }
       
        
           
        
    }
    
    
    public function action_searchId(){
        if($this->validateSearch()){
        
            $data = App::getDB()->select("orders_products",
            [
            "[><]orders" => ["orders_id_orders" => "id_orders"],
        "[><]products " => ["products_id_products" => "id_products"],
              "[><]person " => ["orders.person_id_person" => "id_person"], 
                // "[><]role" => ["person.role_id_role" => "id_role",
        ], [
           
            "orders.id_orders", "id_orders", "date_orders",
            "orders.person_id_person",
            "products_id_products",
            "quantity",
            "products.name(ProductName)",
            "products.price",
            "total",
            "id_person",
            "person.name(PersonName)",
            "person.surname",
            "orders_id_orders",
           // "role.type_role",
            
            
            
            
             
            ] ,["id_orders" => $this->id_orders,
                "ORDER" => "orders_id_orders", "ORDER"=>["orders_id_orders" => "DESC"],],);
        
        
        
        
        App::getSmarty()->assign('data', $data);
            
        App::getSmarty()->display('History_View_Db.tpl');
        }
    }
    ////
    
    
    
    
   
    
    
    public function action_db()
    {
       
    
           $this->action_showDb();
       
     
            
       $this->generateView(); 
        
        
    }
       
        
    

   

   
    public function generateView()
    {
       // getSmarty()->assign('user', unserialize($_SESSION['user']));
       App::getSmarty()->assign('form', $this->form);
        $this->action_showDb();
        App::getSmarty()->assign('page_title', 'Historia');
        App::getSmarty()->display('History_View_Db.tpl');
    }
}