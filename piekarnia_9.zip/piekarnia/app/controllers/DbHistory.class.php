<?php

namespace app\controllers;

use core\App;
use core\Utils;
use core\RoleUtils;
use core\ParamUtils;
use core\Message;
use app\forms\PersonEditForm;
use core\Validator;



class DbHistory
{
//zmienic na private te funkcje jedną!

    private $role;
    private $variable;
    private $form;
    
    
     public function __construct() {
        //stworzenie potrzebnych obiektów
        $this->form = new PersonEditForm();
    }

     
    
    public function action_showDb(){
        
        
        $data = App::getDB()->select("person",[
            "[><]role" => ["role_id_role" => "id_role",
        ]], [
            //"person.type_role",
            "role.type_role", "id_person",
            "name",
            "surname",
            "number_login",
            "password",
            "role_id_role",
            ]);
        
        
        App::getSmarty()->assign('data', $data);
    }
    
    public function validate(){
         $this->role=0;
        
        $this->role = ParamUtils::getFromRequest('rola');
        
        
        $this->form->id = ParamUtils::getFromCleanURL(1);
        
        if($this->role == "klient" || $this->role == "admin" || $this->role == "pracownik")
        {
           return true; 
        }else{
            App::getSmarty()->display('EditViewRole.tpl');
            return false;
        }
       
        
           
        
    }
    
    
    
    
    
    public function action_editRole(){
       
        if($this->validate()) {
        
        $d = App::getDB()->get("role", ["id_role", "type_role"],[
            
            "type_role" => $this->role,
                          
              ]);
        
        
        if(!empty($d))
        {
            $id = $d['id_role']; 
        
       
        App::getDB()->update("person", [
	"role_id_role" => $id,
],["id_person" => $this->form->id]);      
        }
      
        $this->generateView();
    }
      
    }
    
    
    
    
    public function action_db()
    {
       
       //if(RoleUtils::inRole("admin"))
           $this->action_showDb();
       
      // $this->action_showDbPracownik();
       // $this->action_editRole();
        
       // if($this->validate())
      ///// / {
       //     $this->generateView();
            
      //  } else {
            //pozostań na stronie
            //App::getSmarty()->display('EditView.tpl');
      //  }
            
       $this->generateView(); 
        
        
    }
       
        
    

   

   
    public function generateView()
    {
       // getSmarty()->assign('user', unserialize($_SESSION['user']));
       App::getSmarty()->assign('form', $this->form);
        $this->action_showDb();
        App::getSmarty()->assign('page_title', 'Historia');
        App::getSmarty()->display('History_View_Db.tpl');
    }
}