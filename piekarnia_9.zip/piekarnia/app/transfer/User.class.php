<?php

namespace app\transfer;

class User{
	public $login;
        public $id_user;
	
	
	public function __construct($login, $id_user){
		$this->login = $login;
                $this->id_user = $id_user;
			
	}	
}



