<?php

use core\App;
use core\Utils;

App::getRouter()->setDefaultRoute('hello'); #default action
App::getRouter()->setLoginRoute('login'); #action to forward if no permissions

Utils::addRoute('db',     'DbHistory');
Utils::addRoute('editRole',     'DbHistory', ['admin']);
Utils::addRoute('dbProducts',     'DbProducts', ['pracownik']);
Utils::addRoute('editProducts',     'DbProducts', ['pracownik']);
Utils::addRoute('deleteProducts',     'DbProducts', ['pracownik']);
Utils::addRoute('addProducts',     'DbProducts', ['pracownik']);

Utils::addRoute('orderFin',     'Piekarnia');
Utils::addRoute('delete',     'Piekarnia');
Utils::addRoute('piekarnia',     'Piekarnia');
Utils::addRoute('loginShow',     'LoginCtrl');
Utils::addRoute('login',         'LoginCtrl');
Utils::addRoute('logout',        'LoginCtrl');
Utils::addRoute('registration',        'RegistrationCtrl');
//Utils::addRoute('calcShow', 'HelloCtrl', ['user', 'admin']);


Utils::addRoute('hello', 'HelloCtrl');
//Utils::addRoute('action_name', 'controller_class_name');
Utils::addRoute('nowa', 'NowyKontroler');
Utils::addRoute('denied', 'NowyKontroler');