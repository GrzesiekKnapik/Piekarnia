<?php
/* Smarty version 4.1.0, created on 2022-06-03 23:41:21
  from 'C:\Users\Sony_PC\Desktop\xamp_\htdocs\piekarnia\app\views\EditViewProductsAdd.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_629a80016e0072_11574868',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd45898cafab9c6dcf7356f92a1e93a8872d5922c' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\xamp_\\htdocs\\piekarnia\\app\\views\\EditViewProductsAdd.tpl',
      1 => 1654292470,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_629a80016e0072_11574868 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_37827776629a80016d40d4_59781423', 'navigation');
?>




<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_422628377629a80016d6011_17100532', 'header');
?>





<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_224956039629a80016d74c2_80184872', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "main_1.tpl");
}
/* {block 'navigation'} */
class Block_37827776629a80016d40d4_59781423 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navigation' => 
  array (
    0 => 'Block_37827776629a80016d40d4_59781423',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container px-4 px-lg-5">
                <a class="navbar-brand" href="#!">Start Bootstrap</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                        <li class="nav-item"><a class="nav-link active" aria-current="page" href="#!">Home</a></li>
                        <li class="nav-item"><a class="nav-link" href="#!">About</a></li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Shop</a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="#!">All Products</a></li>
                                <li><hr class="dropdown-divider" /></li>
                                <li><a class="dropdown-item" href="#!">Popular Items</a></li>
                                <li><a class="dropdown-item" href="#!">New Arrivals</a></li>
                            </ul>
                        </li>
                    </ul>
                    <form class="d-flex">
                        <button class="btn btn-outline-dark" type="submit">
                            <i class="bi-cart-fill me-1"></i>
                            Cart
                            <span class="badge bg-dark text-white ms-1 rounded-pill">0</span>
                        </button>
                    </form>
                </div>
            </div>
        </nav>
<?php
}
}
/* {/block 'navigation'} */
/* {block 'header'} */
class Block_422628377629a80016d6011_17100532 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'header' => 
  array (
    0 => 'Block_422628377629a80016d6011_17100532',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<header class="bg-dark py-1">
            <div class="container px-4 px-lg-5 my-5">
                <div class="text-center text-white">
                    <h1 class="display-4 fw-bolder">Pod kłosem</h1>
                    <p class="lead fw-normal text-white-50 mb-0">Witamy w naszej piekarni.</p>
                    <p class="lead fw-normal text-white-50 mb-0">Prosimy się zalogować.</p>
                </div>
            </div>
        </header>
<?php
}
}
/* {/block 'header'} */
/* {block 'content'} */
class Block_224956039629a80016d74c2_80184872 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_224956039629a80016d74c2_80184872',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>




<h1> Edycja produktów: </h1>
               


<form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
addProducts" method="post"  class="pure-form pure-form-aligned bottom-margin">
	
	<fieldset>
        <div class="pure-control-group">
			<label for="id_nazwa">nazwa: </label>
			<input id="id_nazwa" type="text" name="nazwa"/>                     
                      <!-- <input type="hidden" name="hidden_id" value="<?php echo \core\ParamUtils::getFromCleanURL(1);?>
" /> -->
                        <label for="id_cena">cena: </label>
			<input id="id_cena" type="text" name="cena"/>
                       
		</div>
       
		<div class="pure-controls">
			<input type="submit" value="zatwierdź" class="pure-button pure-button-primary"/>
		</div>
	</fieldset>
</form>	
                        
                        
                        
                        
                        
                        
               
             
<?php
}
}
/* {/block 'content'} */
}
