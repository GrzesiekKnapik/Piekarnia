<?php
/* Smarty version 4.1.0, created on 2022-05-29 23:43:34
  from 'C:\Users\Sony_PC\Desktop\xamp_\htdocs\piekarnia\app\views\EditView.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_6293e906a061d9_37423178',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd6f88c092b5303e97d96a48ef6f6fe67631acf50' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\xamp_\\htdocs\\piekarnia\\app\\views\\EditView.tpl',
      1 => 1653860611,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6293e906a061d9_37423178 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_5428854366293e9069fd618_67575162', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'content'} */
class Block_5428854366293e9069fd618_67575162 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_5428854366293e9069fd618_67575162',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>




<h1> Edycja: </h1>
               


<form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
editRole/<?php echo \core\ParamUtils::getFromCleanURL(1);?>
" method="post"  class="pure-form pure-form-aligned bottom-margin">
	
	<fieldset>
        <div class="pure-control-group">
			<label for="id_rola">rola: </label>
			<input id="id_rola" type="text" name="rola"/>                     
                      <!-- <input type="hidden" name="hidden_id" value="<?php echo \core\ParamUtils::getFromCleanURL(1);?>
" /> -->
		</div>
       
		<div class="pure-controls">
			<input type="submit" value="zatwierdź" class="pure-button pure-button-primary"/>
		</div>
	</fieldset>
</form>	
               
             
<?php
}
}
/* {/block 'content'} */
}
