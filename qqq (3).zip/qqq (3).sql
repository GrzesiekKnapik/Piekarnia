-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Czas generowania: 10 Cze 2022, 11:20
-- Wersja serwera: 10.4.24-MariaDB
-- Wersja PHP: 8.0.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Baza danych: `bakery`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `orders`
--

CREATE TABLE `orders` (
  `id_orders` int(11) NOT NULL,
  `date_orders` datetime DEFAULT NULL,
  `total` float DEFAULT NULL,
  `person_id_person` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `orders`
--

INSERT INTO `orders` (`id_orders`, `date_orders`, `total`, `person_id_person`) VALUES
(1, '2022-06-09 14:47:27', 3, 13),
(2, '2022-06-09 14:49:29', 1, 13),
(3, '2022-06-09 15:58:53', 3, 13);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `orders_products`
--

CREATE TABLE `orders_products` (
  `orders_id_orders` int(11) NOT NULL,
  `products_id_products` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `orders_products`
--

INSERT INTO `orders_products` (`orders_id_orders`, `products_id_products`, `quantity`) VALUES
(439, 12, 1),
(439, 13, 1),
(440, 12, 1),
(1, 12, 1),
(1, 13, 1),
(2, 12, 1),
(3, 12, 1),
(3, 13, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `person`
--

CREATE TABLE `person` (
  `id_person` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `surname` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `number_login` int(15) NOT NULL,
  `role_id_role` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `person`
--

INSERT INTO `person` (`id_person`, `name`, `surname`, `password`, `number_login`, `role_id_role`) VALUES
(11, 'Grzegorz', 'Knapik', 't', 728950772, 2),
(12, 'Ola', 'Biedroń', 'q', 111, 1),
(13, 'Bonifacy', 'Taki', 'e', 222, 3),
(14, 'Maurycy', 'Niczym', 'rr', 2001, 1),
(15, 'Magda', 'Knot', 'q', 55, 2);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `products`
--

CREATE TABLE `products` (
  `id_products` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `price` float NOT NULL,
  `status` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `products`
--

INSERT INTO `products` (`id_products`, `name`, `price`, `status`) VALUES
(3, 'chalka', 6, 'unavailable'),
(7, 'bagietka', 3, 'unavailable'),
(10, 'chleb', 5, 'unavailable'),
(11, 'Sernik', 11, 'unavailable'),
(12, 'bagietka', 1, 'unavailable'),
(13, 'Chleb', 2, 'unavailable'),
(14, 'bagietka', 3, 'unavailable'),
(15, 'Chleb', 2, 'unavailable'),
(16, 'bagietka', 3, 'unavailable'),
(17, 'Chleb', 2, 'unavailable'),
(18, 'bagietka', 4, 'unavailable'),
(19, 'bagietka', 4, 'unavailable'),
(20, 'bagietka', 3, 'unavailable'),
(21, 'Chleb', 3, 'unavailable'),
(22, 'chalka', 2, 'unavailable'),
(23, 'chalka', 2, 'unavailable'),
(24, 'bagietka', 3, 'unavailable'),
(25, 'bagietka', 2, 'unavailable'),
(26, 'bagietka', 4.5, 'unavailable'),
(27, 'Paczek', 3, 'unavailable'),
(28, 'chalka', 11, 'unavailable'),
(29, 'Paczek', 1, 'unavailable'),
(30, 'Paczek', 1, 'unavailable'),
(31, 'Chleb', 3, 'unavailable'),
(32, 'chalka', 2, 'unavailable'),
(33, 'bagietka', 3, 'unavailable'),
(34, 'bagietka', 3, 'unavailable'),
(35, 'bagietka', 3, 'unavailable'),
(36, 'bagietka', 3, 'unavailable'),
(37, 'bagietka', 3, 'unavailable'),
(38, 'bagietka', 3, 'unavailable'),
(39, 'chalka', 2, 'unavailable'),
(40, 'bagietka', 3, 'unavailable'),
(41, 'Tort chałwowy', 5.5, 'unavailable'),
(42, 'Kremówka', 2, 'unavailable'),
(43, 'Pączek', 1, 'unavailable'),
(44, 'bagietka', 3, 'available'),
(45, 'bagietka', 3, 'available'),
(46, 'bagietka', 3, 'available'),
(47, 'bagietka', 3, 'available'),
(48, 'bagietka', 3, 'available'),
(49, 'bagietka', 3, 'available'),
(50, 'bagietka', 3, 'available'),
(51, 'bagietka', 3, 'available'),
(52, 'bagietka', 3, 'available'),
(53, 'bagietka', 3, 'available'),
(54, 'bagietka', 3, 'available'),
(55, 'bagietka', 3, 'available'),
(56, 'bagietka', 3, 'available'),
(57, 'bagietka', 3, 'available'),
(58, 'bagietka', 3, 'available'),
(59, 'bagietka', 3, 'available'),
(60, 'bagietka', 3, 'available'),
(61, 'bagietka', 3, 'available'),
(62, 'bagietka', 3, 'available'),
(63, 'bagietka', 3, 'available'),
(64, 'bagietka', 3, 'available'),
(65, 'bagietka', 3, 'available'),
(66, 'bagietka', 3, 'available'),
(67, 'bagietka', 3, 'available'),
(68, 'bagietka', 3, 'available'),
(69, 'bagietka', 3, 'available'),
(70, 'bagietka', 3, 'available'),
(71, 'bagietka', 3, 'available');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `role`
--

CREATE TABLE `role` (
  `id_role` int(11) NOT NULL,
  `type_role` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `role`
--

INSERT INTO `role` (`id_role`, `type_role`) VALUES
(1, 'admin'),
(2, 'klient'),
(3, 'pracownik');

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id_orders`),
  ADD KEY `orders_person_fk` (`person_id_person`);

--
-- Indeksy dla tabeli `orders_products`
--
ALTER TABLE `orders_products`
  ADD KEY `orders_products_products_fk` (`products_id_products`),
  ADD KEY `orders_products_orders_fk` (`orders_id_orders`);

--
-- Indeksy dla tabeli `person`
--
ALTER TABLE `person`
  ADD PRIMARY KEY (`id_person`),
  ADD KEY `person_role_fk` (`role_id_role`);

--
-- Indeksy dla tabeli `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id_products`);

--
-- Indeksy dla tabeli `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id_role`);

--
-- AUTO_INCREMENT dla zrzuconych tabel
--

--
-- AUTO_INCREMENT dla tabeli `orders`
--
ALTER TABLE `orders`
  MODIFY `id_orders` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT dla tabeli `person`
--
ALTER TABLE `person`
  MODIFY `id_person` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT dla tabeli `products`
--
ALTER TABLE `products`
  MODIFY `id_products` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT dla tabeli `role`
--
ALTER TABLE `role`
  MODIFY `id_role` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Ograniczenia dla zrzutów tabel
--

--
-- Ograniczenia dla tabeli `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_person_fk` FOREIGN KEY (`person_id_person`) REFERENCES `person` (`id_person`);

--
-- Ograniczenia dla tabeli `orders_products`
--
ALTER TABLE `orders_products`
  ADD CONSTRAINT `orders_products_orders_fk` FOREIGN KEY (`orders_id_orders`) REFERENCES `orders` (`id_orders`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `orders_products_products_fk` FOREIGN KEY (`products_id_products`) REFERENCES `products` (`id_products`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ograniczenia dla tabeli `person`
--
ALTER TABLE `person`
  ADD CONSTRAINT `person_role_fk` FOREIGN KEY (`role_id_role`) REFERENCES `role` (`id_role`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
