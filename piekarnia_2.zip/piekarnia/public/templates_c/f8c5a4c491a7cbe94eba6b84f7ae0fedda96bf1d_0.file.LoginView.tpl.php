<?php
/* Smarty version 4.1.0, created on 2022-05-24 20:16:20
  from 'C:\Users\Sony_PC\Desktop\xamp_\htdocs\piekarnia\app\views\LoginView.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_628d20f4883ad6_58247275',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f8c5a4c491a7cbe94eba6b84f7ae0fedda96bf1d' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\xamp_\\htdocs\\piekarnia\\app\\views\\LoginView.tpl',
      1 => 1653416171,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_628d20f4883ad6_58247275 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>





<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_527440294628d20f487c009_59425030', 'content');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'content'} */
class Block_527440294628d20f487c009_59425030 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_527440294628d20f487c009_59425030',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    

    
<form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
login" method="post"  class="pure-form pure-form-aligned bottom-margin">
	<legend>Logowanie do systemu</legend>
	<fieldset>
        <div class="pure-control-group">
			<label for="id_login">login(numer telefonu): </label>
			<input id="id_login" type="text" name="login"/>
		</div>
        <div class="pure-control-group">
			<label for="id_pass">hasło: </label>
			<input id="id_pass" type="password" name="pass" /><br />
		</div>
		<div class="pure-controls">
			<input type="submit" value="zaloguj" class="pure-button pure-button-primary"/>
		</div>
	</fieldset>
</form>	

        <legend>Jesteś nowym klientem? Zarejestruj się</legend>
        
        
<div class="pure-menu pure-menu-horizontal bottom-margin">
	<a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
registration"  class="pure-menu-heading pure-menu-link">Rejestracja!</a>
</div>
        

<?php
}
}
/* {/block 'content'} */
}
