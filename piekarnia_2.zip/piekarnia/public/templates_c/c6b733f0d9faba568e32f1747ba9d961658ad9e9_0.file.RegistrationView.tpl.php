<?php
/* Smarty version 4.1.0, created on 2022-05-23 20:32:53
  from 'C:\Users\Sony_PC\Desktop\xamp_\htdocs\piekarnia\app\views\RegistrationView.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_628bd355aa36e8_56120857',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c6b733f0d9faba568e32f1747ba9d961658ad9e9' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\xamp_\\htdocs\\piekarnia\\app\\views\\RegistrationView.tpl',
      1 => 1652428261,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_628bd355aa36e8_56120857 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_705010403628bd355a97816_07585491', 'content');
?>


</html><?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'content'} */
class Block_705010403628bd355a97816_07585491 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_705010403628bd355a97816_07585491',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    
       
 <form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
registration" method="post"  class="pure-form pure-form-aligned bottom-margin">
	<legend>Rejestracja do systemu</legend>
	<fieldset>
        <div class="pure-control-group">
			<label for="id_imie">Imie: </label>
			<input id="id_imie" type="text"  placeholder="imie" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->imie;?>
" name="imie"/>
		</div>
        <div class="pure-control-group">
			<label for="id_nazwisko">Nazwisko: </label>
			<input id="id_nazwisko" type="text" placeholder="nazwisko" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->nazwisko;?>
" name="nazwisko" /><br />
		</div>
            <div class="pure-control-group">
			<label for="id_numer">Login(Numer telefonu): </label>
			<input id="id_numer" type="text" placeholder="numer telefonu" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->numer;?>
" name="numer" /><br />
		</div>
            <div class="pure-control-group">
			<label for="id_haslo">Hasło: </label>
			<input id="id_haslo" type="text" placeholder="haslo" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->haslo;?>
" name="haslo" /><br />
		</div>
            <div class="pure-control-group">
			<label for="id_haslo_pow">Powtórz hasło: </label>
			<input id="id_haslo_pow" type="text" placeholder="haslo" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->haslo_pow;?>
"  name="haslo_pow" /><br />
		</div>
		<div class="pure-controls">
			<input type="submit" value="ZAREJESTRUJ" class="pure-button pure-button-primary"/>
		</div>
	</fieldset>
</form>	

  

<?php
}
}
/* {/block 'content'} */
}
