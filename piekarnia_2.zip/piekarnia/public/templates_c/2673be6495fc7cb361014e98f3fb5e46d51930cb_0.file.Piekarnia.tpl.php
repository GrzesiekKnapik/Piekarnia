<?php
/* Smarty version 4.1.0, created on 2022-05-25 22:06:33
  from 'C:\Users\Sony_PC\Desktop\xamp_\htdocs\piekarnia\app\views\Piekarnia.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_628e8c49b84335_18145658',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2673be6495fc7cb361014e98f3fb5e46d51930cb' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\xamp_\\htdocs\\piekarnia\\app\\views\\Piekarnia.tpl',
      1 => 1653509186,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:piekarnia_Db_View.tpl' => 1,
  ),
),false)) {
function content_628e8c49b84335_18145658 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<!DOCTYPE HTML>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="pl" lang="pl">

<head>
	<meta charset="utf-8"/>
	<title>Hello World | Amelia framework</title>
</head>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1956308888628e8c49b571d1_55348578', 'content');
?>


</html><?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main_2.tpl");
}
/* {block 'content'} */
class Block_1956308888628e8c49b571d1_55348578 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_1956308888628e8c49b571d1_55348578',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    
    
  <div class="pure-menu pure-menu-horizontal bottom-margin">
	<a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
logout"  class="pure-menu-heading pure-menu-link">wyloguj</a>
</div>

<div class="pure-menu pure-menu-horizontal bottom-margin">
	<a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
sie"  class="pure-menu-heading pure-menu-link">historia</a>
</div>

        
    
        
        
        
        
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['data_produkty']->value, 't');
$_smarty_tpl->tpl_vars['t']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['t']->value) {
$_smarty_tpl->tpl_vars['t']->do_else = false;
?>
<div class="col-md-4">
 <form method="post" action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
piekarnia">  
                          <div style="border:1px solid #333; background-color:#f1f1f1; border-radius:5px; padding:16px;" align="center">  
                               
                               <h4 class="text-info"><?php echo $_smarty_tpl->tpl_vars['t']->value['nazwa'];?>
</h4>  
                               <h4 class="text-danger">$ <?php echo $_smarty_tpl->tpl_vars['t']->value['cena'];?>
</h4>  
                               <input type="text" name="quantity" class="form-control" value="1" /> 
                               <input type="hidden" name="hidden_id" value="<?php echo $_smarty_tpl->tpl_vars['t']->value["Idprodukty"];?>
" />
                               <input type="hidden" name="hidden_name" value="<?php echo $_smarty_tpl->tpl_vars['t']->value["nazwa"];?>
" />  
                               <input type="hidden" name="hidden_price" value="<?php echo $_smarty_tpl->tpl_vars['t']->value["cena"];?>
" />  
                               <input type="submit" name="add_to_cart" style="margin-top:5px;" class="btn btn-success" value="Add to Cart" />  
                          </div>  
                     </form>  
</div>
<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>

///////

<?php if ((isset($_smarty_tpl->tpl_vars['sesja_koszyk']->value))) {?>       
 <table>   
 <thead>
	<tr>
		
		<th>Nazwa:</th>
		<th>Cena:</th>
                <th>Ilosć:</th>
		<th>Id:</th>
       
	
	</tr>
</thead>
<tbody>       
        
        
<tbody>        
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['sesja_koszyk']->value, 't');
$_smarty_tpl->tpl_vars['t']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['t']->value) {
$_smarty_tpl->tpl_vars['t']->do_else = false;
?>
<tr><td><?php echo $_smarty_tpl->tpl_vars['t']->value['item_name'];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['t']->value['item_price'];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['t']->value['item_quantity'];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['t']->value['item_id'];?>
</td></tr>   
<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
</tbody>

</table>

<?php }?>





///////


 <?php $_smarty_tpl->_subTemplateRender('file:piekarnia_Db_View.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
 
  

<?php
}
}
/* {/block 'content'} */
}
