<?php
/* Smarty version 4.1.0, created on 2022-05-24 17:41:17
  from 'C:\Users\Sony_PC\Desktop\xamp_\htdocs\piekarnia\app\views\History_View_Db.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_628cfc9d4c6206_82434076',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '44d4ec324157c10bba14033e1e015a29faca1cce' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\xamp_\\htdocs\\piekarnia\\app\\views\\History_View_Db.tpl',
      1 => 1653406873,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:records_Db_View.tpl' => 1,
  ),
),false)) {
function content_628cfc9d4c6206_82434076 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_922610872628cfc9d4b8e72_83333652', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'content'} */
class Block_922610872628cfc9d4b8e72_83333652 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_922610872628cfc9d4b8e72_83333652',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<div class="pure-menu pure-menu-horizontal bottom-margin">
	<a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
logout"  class="pure-menu-heading pure-menu-link">wyloguj</a>
</div>

<h1> Historia: </h1>
                <?php $_smarty_tpl->_subTemplateRender('file:records_Db_View.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
                
                
                <div class="pure-menu pure-menu-horizontal bottom-margin">
	<a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
logout"  class="pure-menu-heading pure-menu-link">wyloguj</a>
</div>
               
             
<?php
}
}
/* {/block 'content'} */
}
