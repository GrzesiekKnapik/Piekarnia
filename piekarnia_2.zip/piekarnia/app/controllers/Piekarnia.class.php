<?php


namespace app\controllers;

use core\App;
use core\Message;
use core\Utils;
use core\SessionUtils;
use core\RoleUtils;
use core\ParamUtils;

//


class Piekarnia {
    
    private $total = 0;
    
    public function action_piekarnia() {
       
        App::getSmarty()->assign('page_title', 'Zakupy w piekarni');
        
        
        
        
       //mam tutaj rzeczy z sesji ktore chce wyświetlić w tpl 
       SessionUtils::loadObject('user',true)->login;
       
       //tylko tym sposobem sie tego nie da zrobić chyba
       
       
        
        $data_produkty = App::getDB()->select("produkty", [
            "Idprodukty",
            "nazwa",
            "cena",
        ]);
       App::getSmarty()->assign('data_produkty', $data_produkty);
         
        ///////////////////////////////////////////////////
       
       if((ParamUtils::getFromRequest('add_to_cart', $required = true)))  
       {
           
           if(isset($_SESSION["shopping_cart"]))  
           {  
           $item_array_id = array_column($_SESSION["shopping_cart"], "item_id");  
           if(!in_array(ParamUtils::getFromRequest('hidden_id'), $item_array_id))  
           {  
                $count = count($_SESSION["shopping_cart"]);  
                $item_array = array(  
                     'item_id'               =>    ParamUtils::getFromRequest('hidden_id'),  
                     'item_name'               =>     ParamUtils::getFromRequest('hidden_name'),  
                     'item_price'          =>     ParamUtils::getFromRequest('hidden_price'),  
                     'item_quantity'          =>    ParamUtils::getFromRequest('quantity')  
                );  
                $_SESSION["shopping_cart"][$count] = $item_array;  
                Utils::addErrorMessage('Tego jeszcze nie było');
                
           }  
           else  
           {  
               Utils::addErrorMessage('Taki produkt został już dodany');
               //redirecta tu 
                 
           }  
      }  
      else  
      {  
           $item_array = array(  
                'item_id'               =>     ParamUtils::getFromRequest('hidden_id'),  
                'item_name'               =>    ParamUtils::getFromRequest('hidden_name'),    
                'item_price'          =>     ParamUtils::getFromRequest('hidden_price'),  
                'item_quantity'          =>     ParamUtils::getFromRequest('quantity')    
           );  
           $_SESSION["shopping_cart"][0] = $item_array;  
          
      }  
       
       
      
    }
    
    
   
    
   
    
   
   // $a = SessionUtils::loadObject('user',true)->login;
   // App::getSmarty()->assign('sesjaa', $a);
    if(!empty($_SESSION["shopping_cart"])){
        foreach ($_SESSION["shopping_cart"] as $t)
    {
        
        $this->total = $this->total + ($t["item_quantity"] * $t["item_price"]);  
        
    }
        
    App::getSmarty()->assign('total', $this->total);
    App::getSmarty()->assign('sesja_koszyk', $_SESSION["shopping_cart"]);
   
    }
    /*
     if(!empty($_SESSION["shopping_cart"]))  
                          {  
                               $total = 0;  
                               foreach($_SESSION["shopping_cart"] as $keys => $values)  
                               {  
                          ?>  
                          <tr>  
                               <td><?php echo $values["item_name"]; ?></td>  
                               <td><?php echo $values["item_quantity"]; ?></td>  
                               <td>$ <?php echo $values["item_price"]; ?></td>  
                               <td>$ <?php echo number_format($values["item_quantity"] * $values["item_price"], 2); ?></td>  
                               <td><a href="index.php?action=delete&id=<?php echo $values["item_id"]; ?>"><span class="text-danger">Remove</span></a></td>  
                          </tr>  
                          <?php  
                                    $total = $total + ($values["item_quantity"] * $values["item_price"]);  
                               }  
                          ?>  
                          <tr>  
                               <td colspan="3" align="right">Total</td>  
                               <td align="right">$ <?php echo number_format($total, 2); ?></td>  
                               <td></td>  
                          </tr>  
                          <?php  
                          }  
    
    */
    
 
 
    
       
       
       /////////////////////////////////////////////////////////////////////////////////
        
        
        
        App::getSmarty()->display("Piekarnia.tpl");
        
         
        
        
      
        
    }
    
   
       
}
