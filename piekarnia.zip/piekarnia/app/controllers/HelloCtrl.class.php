<?php

namespace app\controllers;

use core\App;
use core\Message;
use core\Utils;


class HelloCtrl {
    
    public function action_hello() {
        
        
        $data_items = App::getDB()->select("products", [
            "id_products",
            "name",
            "price",
            
        ],["status" => "available"]);
       App::getSmarty()->assign('data_items', $data_items);
         
		        
        //App::getSmarty()->assign('page_title', 'Piekarnia pod kłosem');       
        App::getSmarty()->display("Hello.tpl");
        
        //App::getSmarty()->display("Summary.tpl");
        
    }
    
}
