<?php

namespace app\controllers;

use core\App;
use core\Utils;
use core\RoleUtils;
use core\ParamUtils;
use core\Message;
use app\forms\PersonEditForm;
use core\Validator;



class DbProducts
{
//zmienic na private te funkcje jedną!

    private $id;
    private $name;
    private $price;
    
    public function action_showDb(){
      
        
        $dataProducts = App::getDB()->select("products", [
            "id_products",
            "name",
            "price",
            "status",
            
        ]);
        
        
        App::getSmarty()->assign('dataProducts', $dataProducts);
    }
    
    
    public function validate(){
         
       
        
        $this->name = ParamUtils::getFromRequest('nazwa');
        $this->price = ParamUtils::getFromRequest('cena');
        
        $this->id = ParamUtils::getFromCleanURL(1);
        
        if( !empty($this->name) || !empty($this->price))
        {
           return true; 
        }else{
            App::getSmarty()->display('EditViewProducts.tpl');
            return false;
        }
         
    }
    
    
    public function validateAdd(){
         
       
        
        $this->name = ParamUtils::getFromRequest('nazwa');
        $this->price = ParamUtils::getFromRequest('cena');
        
        
        if( !empty($this->name) || !empty($this->price))
        {
           return true; 
        }else{
            App::getSmarty()->display('EditViewProductsAdd.tpl');
            return false;
        }
        
           
        
    }
    
    
    
    
     public function action_deleteProducts(){
       // echo '<script>alert("Item Removed")</script>';
				//echo '<script>window.location="index.php"</script>';

 
   // echo '<script> ';  
    //echo ' function openulr(newurl) {';  
  //  echo '  if (confirm("Are you sure you want to open new URL")) {';  
   // echo '   window.location="http://localhost/piekarnia/public/addProducts"';  
   // echo '  }else{window.location="http://localhost/piekarnia/public/dbProducts" }';
   
   // echo '}';  
   //  echo '</script>';  
  


        $this->id = ParamUtils::getFromCleanURL(1);
        App::getDB()->update("products", [
        "status" => "unavailable"	
],[ "id_products" => $this->id]);     
      
      
        $this->generateView();
        
    }
    
    
     public function action_addProducts(){
         
         if($this->validateAdd()){
         App::getDB()->insert("products", [
           
        "name" => $this->name,
         "price" => $this->price,
             "status" => "available"
]);     
         $this->generateView();
         }
    }
    
    
    
    public function action_dbProducts(){
         $this->action_showDb();
        
        $this->generateView();
    }
     

     
    
    
    

   

   
    public function generateView()
    {
       // getSmarty()->assign('user', unserialize($_SESSION['user']));
      
        $this->action_showDb();
        App::getSmarty()->assign('page_title', 'Historia');
        App::getSmarty()->display('ViewProducts.tpl');
    }
}