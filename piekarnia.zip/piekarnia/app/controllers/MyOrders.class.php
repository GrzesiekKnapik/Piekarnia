<?php


namespace app\controllers;

use core\App;
use core\Message;
use core\Utils;
use core\SessionUtils;
use core\RoleUtils;
use core\ParamUtils;

//


class MyOrders {
    
    





    
    
     
 
 public function action_myOrders(){

    
     
     
    
    
    $dataSummary = App::getDB()->select("orders_products",
            [
            "[><]orders" => ["orders_id_orders" => "id_orders"],
        "[><]products " => ["products_id_products" => "id_products"],
              "[><]person " => ["orders.person_id_person" => "id_person"], 
            
        ], [
            //"person.type_role",
            "orders.id_orders", "id_orders", "date_orders",
            "orders.person_id_person",
            "products_id_products",
            "quantity",
            "products.name(ProductName)",
            "products.price",
            "total",
            "id_person",
            "person.name(PersonName)",
            "person.surname",
            
           

             
            ],[
		"id_person" => SessionUtils::loadObject('user',$keep=true)->id_user
	],);
     
    
         
      App::getSmarty()->assign('dataSummary', $dataSummary); 
      //App::getRouter()->redirectTo("hello");
     $this->generateView();
      
     
    
     
 }
      
 
 
 public function generateView() {     
    
      App::getSmarty()->display("MyOrdersView.tpl");
    }


     
        
        
      
        
    }
    
   
       



