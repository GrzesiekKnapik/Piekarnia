<?php


namespace app\controllers;

use core\App;
use core\Message;
use core\Utils;
use core\SessionUtils;
use core\RoleUtils;
use core\ParamUtils;

//


class Summary {
    
    private $total;
    private  $id_orders;










    public function action_orderFinInsert(){
        if(!empty($_SESSION["shopping_cart"])){
       foreach ($_SESSION["shopping_cart"] as $t)
    {
         
        $this->total = $this->total + ($t["item_quantity"] * $t["item_price"]);  
        
    }
      
    }
    
     $today = date("Y-m-d H:i:s");
      App::getDB()->insert("orders", [
          "date_orders" => $today,
          "total" =>  $this->total,
            "person_id_person" => SessionUtils::loadObject('user',$keep=true)->id_user,
           
        ]); 
      
      
      $this->id_orders = App::getDB()->id();
      
    
   
     foreach ($_SESSION["shopping_cart"] as $v =>$t){

               
               
               //SessionUtils::loadObject('user',$keep=true)->id_user;
               //#orders_id_orders
               
                App::getDB()->insert("orders_products", [
                    //orders_id_orders nie ma w php my admin powiazania po najechaniu
            "orders_id_orders" => $this->id_orders,
            "products_id_products" => $t['item_id'],
            "quantity" =>  $t['item_quantity'],
            
            
        ]);  
               
               
     }
     
     //unset($_SESSION["shopping_cart"][""]);
     SessionUtils::remove("shopping_cart");
     App::getRouter()->redirectTo("orderFin/$this->id_orders");
        
    }
    
    
    
     
 
 public function action_orderFin(){

    
     
     
    //teraz tu
    $id_orders = ParamUtils::getFromCleanURL(1); 
    $dataSummary = App::getDB()->select("orders_products",
            [
            "[><]orders" => ["orders_id_orders" => "id_orders"],
        "[><]products " => ["products_id_products" => "id_products"],
              "[><]person " => ["orders.person_id_person" => "id_person"], 
            
        ], [
            //"person.type_role",
            "orders.id_orders", "id_orders", "date_orders",
            "orders.person_id_person",
            "products_id_products",
            "quantity",
            "products.name(ProductName)",
            "products.price",
            "total",
            "id_person",
            "person.name(PersonName)",
            "person.surname"
            
             
            ],[
		"orders.id_orders" => $id_orders,
	],);
     
    
         
      App::getSmarty()->assign('dataSummary', $dataSummary); 
      //App::getRouter()->redirectTo("hello");
     $this->generateView();
      
     
    
     
 }
      
 
 
 public function generateView() {     
    
      App::getSmarty()->display("Summary.tpl");
    }


     
        
        
      
        
    }
    
   
       



