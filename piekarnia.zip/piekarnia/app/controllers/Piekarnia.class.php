<?php


namespace app\controllers;

use core\App;
use core\Message;
use core\Utils;
use core\RoleUtils;
use core\ParamUtils;

//


class Piekarnia {
    
    
    public function action_piekarnia() {
       
        App::getSmarty()->assign('page_title', 'Zakupy w piekarni');
              
        
        
         
        if (RoleUtils::inRole("admin"))
       echo "adminn";
        
        
        
        App::getSmarty()->display("Piekarnia.tpl");
        
         
      
        
    }
    
   
       
}
