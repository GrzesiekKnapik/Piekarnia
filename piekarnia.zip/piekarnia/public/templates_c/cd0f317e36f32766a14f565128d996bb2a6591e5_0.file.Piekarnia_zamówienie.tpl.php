<?php
/* Smarty version 4.1.0, created on 2022-05-25 21:33:38
  from 'C:\Users\Sony_PC\Desktop\xamp_\htdocs\piekarnia\app\views\Piekarnia_zamówienie.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_628e8492b72d35_42572133',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'cd0f317e36f32766a14f565128d996bb2a6591e5' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\xamp_\\htdocs\\piekarnia\\app\\views\\Piekarnia_zamówienie.tpl',
      1 => 1653507172,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:piekarnia_Db_View.tpl' => 1,
  ),
),false)) {
function content_628e8492b72d35_42572133 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<!DOCTYPE HTML>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="pl" lang="pl">

<head>
	<meta charset="utf-8"/>
	<title>Hello World | Amelia framework</title>
</head>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_307571410628e8492b43d18_80547252', 'content');
?>


</html><?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main_2.tpl");
}
/* {block 'content'} */
class Block_307571410628e8492b43d18_80547252 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_307571410628e8492b43d18_80547252',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    
    
        
 <table>   
 <thead>
	<tr>
		
		<th>Nazwa:</th>
		<th>Cena:</th>
                <th>Ilosć:</th>
		<th>Id:</th>
       
	
	</tr>
</thead>
<tbody>       
        
        
<tbody>        
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['sesja_koszyk']->value, 't');
$_smarty_tpl->tpl_vars['t']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['t']->value) {
$_smarty_tpl->tpl_vars['t']->do_else = false;
?>
<tr><td><?php echo $_smarty_tpl->tpl_vars['t']->value['item_name'];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['t']->value['item_price'];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['t']->value['item_quantity'];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['t']->value['item_id'];?>
</td></tr>   
<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
</tbody>

</table>
///////



 





///////


 <?php $_smarty_tpl->_subTemplateRender('file:piekarnia_Db_View.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
 
  

<?php
}
}
/* {/block 'content'} */
}
