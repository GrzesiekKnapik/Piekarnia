<?php
/* Smarty version 4.1.0, created on 2022-05-08 00:14:51
  from 'C:\Users\Sony_PC\Desktop\XAMP\htdocs\amelia\app\views\Nowy_widok.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_6276ef5b6c8886_38709087',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6af6dea35985aca0b3cf4de094bd90ff73b42592' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\XAMP\\htdocs\\amelia\\app\\views\\Nowy_widok.tpl',
      1 => 1651961686,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6276ef5b6c8886_38709087 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE HTML>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="pl" lang="pl">

<head>
	<meta charset="utf-8"/>
	<title>Hello World | Amelia framework</title>
</head>

<body>
    
  
   
    
Wyświetlenie listy komunikatów:

<?php if ($_smarty_tpl->tpl_vars['msgs']->value->isInfo()) {?>
<ul>
  <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getMessages(), 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
  <li><?php echo $_smarty_tpl->tpl_vars['msg']->value->text;?>
</li>
  <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
</ul>
<?php }?>



</body>

</html><?php }
}
