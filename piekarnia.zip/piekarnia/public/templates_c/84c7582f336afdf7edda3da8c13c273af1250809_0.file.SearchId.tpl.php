<?php
/* Smarty version 4.1.0, created on 2022-06-13 10:05:02
  from 'C:\Users\Sony_PC\Desktop\xamp_\htdocs\piekarnia\app\views\SearchId.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_62a6efae7f6366_79254040',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '84c7582f336afdf7edda3da8c13c273af1250809' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\xamp_\\htdocs\\piekarnia\\app\\views\\SearchId.tpl',
      1 => 1654858563,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62a6efae7f6366_79254040 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>




<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_83960384662a6efae7e22c3_04650804', 'navigation');
?>




<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_86360793162a6efae7f3338_10945716', 'header');
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_20702305662a6efae7f4558_48791435', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "main_1.tpl");
}
/* {block 'navigation'} */
class Block_83960384662a6efae7e22c3_04650804 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navigation' => 
  array (
    0 => 'Block_83960384662a6efae7e22c3_04650804',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container px-4 px-lg-5">
                <a class="navbar-brand" href="#!">Kłos</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                        <li class="nav-item"><a class="nav-link active" aria-current="page" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
logout">Wyloguj</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
piekarnia">Piekarnia</a></li>
                        
                    </ul>
                    
                </div>
            </div>
        </nav>
<?php
}
}
/* {/block 'navigation'} */
/* {block 'header'} */
class Block_86360793162a6efae7f3338_10945716 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'header' => 
  array (
    0 => 'Block_86360793162a6efae7f3338_10945716',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<header class="bg-dark py-1">
            <div class="container px-4 px-lg-5 my-5">
                <div class="text-center text-white">
                    <h1 class="display-4 fw-bolder">Pod kłosem</h1>
                    <p class="lead fw-normal text-white-50 mb-0">Wyszukiwanie Id.</p>

                </div>
            </div>
        </header>
<?php
}
}
/* {/block 'header'} */
/* {block 'content'} */
class Block_20702305662a6efae7f4558_48791435 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_20702305662a6efae7f4558_48791435',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>




<h1> Wyszukiwanie: </h1>
               


<form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
searchId" method="post"  class="pure-form pure-form-aligned bottom-margin">
	
	<fieldset>
        <div class="pure-control-group">
			<label for="id_id_orders">Id zamówienia: </label>
			<input id="id_id_orders" type="text" name="id_orders"/>                     
                     
		</div>
       
                
                <div class=" pt-0 border-top-0 bg-transparent offset-2">
    <input type="submit" value="zatwierdź" class="p-1 btn-outline-dark "/>
	</div>
		
	</fieldset>
</form>	
               
             
<?php
}
}
/* {/block 'content'} */
}
