<?php
/* Smarty version 4.1.0, created on 2022-05-13 10:09:14
  from 'C:\Users\Sony_PC\Desktop\XAMP\htdocs\piekarnia\app\views\Piekarnia.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_627e122a34c9c5_05467312',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '674947a7f34dc984d295f088e62b974c5da98584' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\XAMP\\htdocs\\piekarnia\\app\\views\\Piekarnia.tpl',
      1 => 1652429352,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_627e122a34c9c5_05467312 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<!DOCTYPE HTML>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="pl" lang="pl">

<head>
	<meta charset="utf-8"/>
	<title>Hello World | Amelia framework</title>
</head>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1839902384627e122a344489_63278082', 'content');
?>


</html><?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'content'} */
class Block_1839902384627e122a344489_63278082 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_1839902384627e122a344489_63278082',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    
    
  <div class="pure-menu pure-menu-horizontal bottom-margin">
	<a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
logout"  class="pure-menu-heading pure-menu-link">wyloguj</a>
</div>

<div class="pure-menu pure-menu-horizontal bottom-margin">
	<a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
showDbHistory"  class="pure-menu-heading pure-menu-link">historia</a>
</div>
  
 
  

<?php
}
}
/* {/block 'content'} */
}
