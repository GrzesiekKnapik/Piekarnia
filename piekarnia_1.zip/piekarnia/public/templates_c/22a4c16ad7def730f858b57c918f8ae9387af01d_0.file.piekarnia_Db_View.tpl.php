<?php
/* Smarty version 4.1.0, created on 2022-05-24 17:48:13
  from 'C:\Users\Sony_PC\Desktop\xamp_\htdocs\piekarnia\app\views\templates\piekarnia_Db_View.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_628cfe3d9dc103_56593627',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '22a4c16ad7def730f858b57c918f8ae9387af01d' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\xamp_\\htdocs\\piekarnia\\app\\views\\templates\\piekarnia_Db_View.tpl',
      1 => 1653407288,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_628cfe3d9dc103_56593627 (Smarty_Internal_Template $_smarty_tpl) {
?><table>
<thead>
	<tr>
		
		<th>Nazwa:</th>
		<th>Cena:</th>
       
	
	</tr>
</thead>
<tbody>
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['data_produkty']->value, 't');
$_smarty_tpl->tpl_vars['t']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['t']->value) {
$_smarty_tpl->tpl_vars['t']->do_else = false;
?>
<tr><td><?php echo $_smarty_tpl->tpl_vars['t']->value['nazwa'];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['t']->value['cena'];?>
</td></tr>
<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
</tbody>
</table><?php }
}
