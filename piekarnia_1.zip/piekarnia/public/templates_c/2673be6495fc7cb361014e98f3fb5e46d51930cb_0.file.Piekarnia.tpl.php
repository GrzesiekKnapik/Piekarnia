<?php
/* Smarty version 4.1.0, created on 2022-05-24 17:46:24
  from 'C:\Users\Sony_PC\Desktop\xamp_\htdocs\piekarnia\app\views\Piekarnia.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_628cfdd03ae6b4_26972443',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2673be6495fc7cb361014e98f3fb5e46d51930cb' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\xamp_\\htdocs\\piekarnia\\app\\views\\Piekarnia.tpl',
      1 => 1653407118,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:piekarnia_Db_View.tpl' => 1,
  ),
),false)) {
function content_628cfdd03ae6b4_26972443 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<!DOCTYPE HTML>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="pl" lang="pl">

<head>
	<meta charset="utf-8"/>
	<title>Hello World | Amelia framework</title>
</head>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1449592051628cfdd03a1995_12650682', 'content');
?>


</html><?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'content'} */
class Block_1449592051628cfdd03a1995_12650682 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_1449592051628cfdd03a1995_12650682',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    
    
  <div class="pure-menu pure-menu-horizontal bottom-margin">
	<a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
logout"  class="pure-menu-heading pure-menu-link">wyloguj</a>
</div>

<div class="pure-menu pure-menu-horizontal bottom-margin">
	<a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
sie"  class="pure-menu-heading pure-menu-link">historia</a>
</div>

 <?php $_smarty_tpl->_subTemplateRender('file:piekarnia_Db_View.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
 
  

<?php
}
}
/* {/block 'content'} */
}
