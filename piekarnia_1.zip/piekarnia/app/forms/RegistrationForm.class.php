<?php

namespace app\forms;

class RegistrationForm {
	public $imie;
	public $nazwisko;
        public $numer;
	public $haslo;
        public $haslo_pow;
	
        
} 