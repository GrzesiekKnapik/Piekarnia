<?php

namespace app\controllers;

use core\App;
use core\Message;
use core\Utils;
use core\ParamUtils;
use app\forms\RegistrationForm;
use core\Validator;
//login musi byc inny zawzze a haslo moze byc takie samo

class RegistrationCtrl {
    
    //dodac value do tpl
    //dopisac tu const itp...
    private $form;
    
    
     public function __construct() {
        //stworzenie potrzebnych obiektów
        $this->form = new RegistrationForm();
    }
    
    public function validate() {
        $this->form->imie = ParamUtils::getFromRequest('imie');
        $this->form->nazwisko = ParamUtils::getFromRequest('nazwisko');
        $this->form->numer = ParamUtils::getFromRequest('numer');
        $this->form->haslo = ParamUtils::getFromRequest('haslo');
        $this->form->haslo_pow = ParamUtils::getFromRequest('haslo_pow');

        //gdy nie z formularza wywolamy
        if (  (!isset($this->form->imie) || !isset($this->form->nazwisko) || !isset($this->form->numer) || !isset($this->form->haslo) || !isset($this->form->haslo_pow ))) return false;

        // sprawdzenie, czy potrzebne wartości zostały przekazane
        if (empty($this->form->imie)) {
            Utils::addErrorMessage('Imie nie zostało podane');
        }
        if (empty($this->form->nazwisko)) {
            Utils::addErrorMessage('Nazwisko nie zostało podane');
        }
         if (empty($this->form->numer)) {
            Utils::addErrorMessage('Numer nie został podany');
        }
        ////////////////////////////////////////////////
        /*
        $v = new Validator();
$num = $v->validate($this->form->numer, [
    'int' => true,
    'validator_message' => 'Musi być wartość całkowita'
]);     
         * */
         
        //$this->numberVal();
       
        
        //unikalnosc loginu sprawdza i empty 
        if((!empty($this->numberValDb()) && ($this->numberVal()->isLastOk()) ))
            {               
                Utils::addErrorMessage('Taki numer juz istnieje, wprowadź inny numer');      
            }
        
        

        /////////////////////////////////////////////////////////////////////
         if (empty($this->form->haslo)) {
            Utils::addErrorMessage('Hasło nie zostało podane');
        }
         if (empty($this->form->haslo_pow)) {
            Utils::addErrorMessage('Powtórz hasło');
        }
        
        
        if($this->form->haslo != $this->form->haslo_pow )
        {
            Utils::addErrorMessage('Hasła są różne');
        }
         
         
        //gdy chociaż jeden error z message to juz false
         if (App::getMessages()->isError())
         {
             return false;
         }else
            return true;
         
         //mozna tez tak to ^
         //return !App::getMessages()->isError();
            
         
         
        }
    
    
    
    
    
    
    
    
    
    
    
    
    public function action_registration() {
        if ($this->validate()) {
            
            //zalogowany => przekieruj na główną akcję (z przekazaniem messages przez sesję)
           
            
             $this->toDb();
           
            Utils::addInfoMessage('Poprawnie zrejestrowano do systemu');
            App::getRouter()->forwardTo("piekarnia");
        } else {
            //niezalogowany => pozostań na stronie logowania
            $this->generateView();
        }
    }

   
        
    public function generateView() {
        App::getSmarty()->assign('form', $this->form); // dane formularza do widoku
        App::getSmarty()->assign('page_title', 'Strona rejestracji');       
        App::getSmarty()->display("RegistrationView.tpl");
    }
        
   
    private function toDb()
    {
        App::getDB()->insert("registration", [
            "imie" => $this->form->imie,
            "nazwisko" => $this->form->nazwisko,
            "numer" => $this->form->numer,
            "haslo" => $this->form->haslo,    
        ]);   
    }   
    
    
    private function numberValDb()
    {
       $data = App::getDB()->select("registration", ["numer"],[
            "numer" => $this->form->numer    
        ]); 
       
       return $data; 
    }
    
    private function numberVal()
    {
        $v = new Validator();  //dokonczyc funkcje!
        $num = $v->validate($this->form->numer, [
    'int' => true,
    'validator_message' => 'Musi być wartość całkowita'
    ]);     
     return $v;   
    }
    
   
    
     
        
    
    
    
}
