<?php

namespace app\forms;

class RegistrationForm {
	public $name;
	public $surname;
        public $number;
	public $password;
        public $password_re;
	
        
} 