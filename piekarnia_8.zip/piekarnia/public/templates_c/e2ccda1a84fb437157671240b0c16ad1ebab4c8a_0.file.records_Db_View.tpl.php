<?php
/* Smarty version 4.1.0, created on 2022-06-03 13:32:28
  from 'C:\Users\Sony_PC\Desktop\xamp_\htdocs\piekarnia\app\views\templates\records_Db_View.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_6299f14cc88f81_94279582',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e2ccda1a84fb437157671240b0c16ad1ebab4c8a' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\xamp_\\htdocs\\piekarnia\\app\\views\\templates\\records_Db_View.tpl',
      1 => 1654254957,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6299f14cc88f81_94279582 (Smarty_Internal_Template $_smarty_tpl) {
?><table>
<thead>
	<tr>
		
		<th>Person_id</th>
                <th>Name</th>
                <th>Surname</th>
                <?php if (\core\RoleUtils::inRole("admin")) {?>
                <th>Number_login</th>
		<th>Role</th>
                <?php }?>
	
	</tr>
</thead>
<tbody>
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['data']->value, 't');
$_smarty_tpl->tpl_vars['t']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['t']->value) {
$_smarty_tpl->tpl_vars['t']->do_else = false;
?>
<tr><td><?php echo $_smarty_tpl->tpl_vars['t']->value['id_person'];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['t']->value['name'];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['t']->value['surname'];?>
</td><?php if (\core\RoleUtils::inRole("admin")) {?><td><?php echo $_smarty_tpl->tpl_vars['t']->value['number_login'];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['t']->value['role_id_role'];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['t']->value['type_role'];?>
</td><td><a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
editRole/<?php echo $_smarty_tpl->tpl_vars['t']->value['id_person'];?>
"<span class="text-danger">Edytuj</span></a></td><?php }?></tr>
<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>

</tbody>
</table><?php }
}
