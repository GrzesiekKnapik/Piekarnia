<?php
/* Smarty version 4.1.0, created on 2022-06-02 23:07:36
  from 'C:\Users\Sony_PC\Desktop\xamp_\htdocs\piekarnia\app\views\templates\main_1.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_6299269860cf63_56058055',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '45c9f595afc3565a65dacbdf030ea8ef9942fa8a' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\xamp_\\htdocs\\piekarnia\\app\\views\\templates\\main_1.tpl',
      1 => 1654203933,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6299269860cf63_56058055 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>
<!doctype html>
<html lang="pl">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	
	<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        
        <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/css/styles.css">	
        
        <link rel="stylesheet" href="https://unpkg.com/purecss@0.6.2/build/pure-min.css" integrity="sha384-UQiGfs9ICog+LwheBSRCt1o5cbyKIHbwjWscjemyBMT9YCUMZffs6UqUTd0hObXD" crossorigin="anonymous">
        <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/css/style.css">	
        
</head>
<body>

<div class="navigation">
	<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_992627230629926985ee372_46421477', 'navigation');
?>

</div>    
    
    
    
<div class="header">
	<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_970774716629926985efbc9_89027491', 'header');
?>

</div>

<div class="content">
<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_366288195629926985f0d75_12895525', 'content');
?>








<?php if ($_smarty_tpl->tpl_vars['msgs']->value->isMessage()) {?>

	
	<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getMessages(), 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
	<li class="msg <?php if ($_smarty_tpl->tpl_vars['msg']->value->isError()) {?>error<?php }?> <?php if ($_smarty_tpl->tpl_vars['msg']->value->isWarning()) {?>warning<?php }?> <?php if ($_smarty_tpl->tpl_vars['msg']->value->isInfo()) {?>info<?php }?>"><?php echo $_smarty_tpl->tpl_vars['msg']->value->text;?>
</li>
	<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
	
        &emsp;
<?php }?>







</div><!-- content -->

<?php if ($_smarty_tpl->tpl_vars['msgs']->value->isMessage() || !empty($_smarty_tpl->tpl_vars['shopping_cart']->value)) {?>
<div class="footer">
    <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_13220666162992698608067_61249671', 'footer');
?>


</div>    
 <?php }?>  


<?php if (!$_smarty_tpl->tpl_vars['msgs']->value->isMessage() && empty($_smarty_tpl->tpl_vars['shopping_cart']->value)) {?>
<div class="footer na_dole">
    <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_7264649766299269860b505_30229139', 'footer');
?>


</div>    
 <?php }?>       

</body>
</html>

<?php }
/* {block 'navigation'} */
class Block_992627230629926985ee372_46421477 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navigation' => 
  array (
    0 => 'Block_992627230629926985ee372_46421477',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 Domyślna treść zawartości .... <?php
}
}
/* {/block 'navigation'} */
/* {block 'header'} */
class Block_970774716629926985efbc9_89027491 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'header' => 
  array (
    0 => 'Block_970774716629926985efbc9_89027491',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 Domyślna treść zawartości .... <?php
}
}
/* {/block 'header'} */
/* {block 'content'} */
class Block_366288195629926985f0d75_12895525 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_366288195629926985f0d75_12895525',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 Domyślna treść zawartości .... <?php
}
}
/* {/block 'content'} */
/* {block 'footer'} */
class Block_13220666162992698608067_61249671 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_13220666162992698608067_61249671',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 <footer class="py-5 bg-dark">
            <div class="container"><p class="m-0 text-center text-white">Copyright &copy; Your Website 2022</p></div>
        </footer> <?php
}
}
/* {/block 'footer'} */
/* {block 'footer'} */
class Block_7264649766299269860b505_30229139 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_7264649766299269860b505_30229139',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 <footer class="py-5 bg-dark">
            <div class="container"><p class="m-0 text-center text-white">Copyright &copy; Your Website 2022</p></div>
        </footer> <?php
}
}
/* {/block 'footer'} */
}
