<?php
/* Smarty version 4.1.0, created on 2022-05-27 14:53:04
  from 'C:\Users\Sony_PC\Desktop\xamp_\htdocs\piekarnia\app\views\templates\piekarnia_Db_View.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_6290c9b048c983_58872403',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '22a4c16ad7def730f858b57c918f8ae9387af01d' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\xamp_\\htdocs\\piekarnia\\app\\views\\templates\\piekarnia_Db_View.tpl',
      1 => 1653655976,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6290c9b048c983_58872403 (Smarty_Internal_Template $_smarty_tpl) {
?><table>
<thead>
	<tr>
		
		<th>Nazwa:</th>
		<th>Cena:</th>
       
	
	</tr>
</thead>
<tbody>

</tbody>
</table>


<?php }
}
