<?php
/* Smarty version 4.1.0, created on 2022-06-03 18:30:29
  from 'C:\Users\Sony_PC\Desktop\xamp_\htdocs\piekarnia\app\views\ViewProducts.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_629a37251f2c54_43264720',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd5434fb0f01a338b3dd2ab019c23a7cf3cc61cd1' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\xamp_\\htdocs\\piekarnia\\app\\views\\ViewProducts.tpl',
      1 => 1654273826,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_629a37251f2c54_43264720 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1994429666629a37251d6df7_00773257', 'navigation');
?>




<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_2020932767629a37251d87c4_01785624', 'header');
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1500590987629a37251d9cc7_49402980', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "main_1.tpl");
}
/* {block 'navigation'} */
class Block_1994429666629a37251d6df7_00773257 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navigation' => 
  array (
    0 => 'Block_1994429666629a37251d6df7_00773257',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container px-4 px-lg-5">
                <a class="navbar-brand" href="#!">Start Bootstrap</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                        <li class="nav-item"><a class="nav-link active" aria-current="page" href="#!">Home</a></li>
                        <li class="nav-item"><a class="nav-link" href="#!">About</a></li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Shop</a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="#!">All Products</a></li>
                                <li><hr class="dropdown-divider" /></li>
                                <li><a class="dropdown-item" href="#!">Popular Items</a></li>
                                <li><a class="dropdown-item" href="#!">New Arrivals</a></li>
                            </ul>
                        </li>
                    </ul>
                    <form class="d-flex">
                        <button class="btn btn-outline-dark" type="submit">
                            <i class="bi-cart-fill me-1"></i>
                            Cart
                            <span class="badge bg-dark text-white ms-1 rounded-pill">0</span>
                        </button>
                    </form>
                </div>
            </div>
        </nav>
<?php
}
}
/* {/block 'navigation'} */
/* {block 'header'} */
class Block_2020932767629a37251d87c4_01785624 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'header' => 
  array (
    0 => 'Block_2020932767629a37251d87c4_01785624',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<header class="bg-dark py-1">
            <div class="container px-4 px-lg-5 my-5">
                <div class="text-center text-white">
                    <h1 class="display-4 fw-bolder">Pod kłosem</h1>
                    <p class="lead fw-normal text-white-50 mb-0">Witamy w naszej piekarni.</p>
                    <p class="lead fw-normal text-white-50 mb-0">Prosimy się zalogować.</p>
                </div>
            </div>
        </header>
<?php
}
}
/* {/block 'header'} */
/* {block 'content'} */
class Block_1500590987629a37251d9cc7_49402980 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_1500590987629a37251d9cc7_49402980',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>




<table>
<thead>
	<tr>
		
		<th>Nazwa</th>
                <th>Cena</th>
               
	
	</tr>
</thead>
<tbody>
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['dataProducts']->value, 't');
$_smarty_tpl->tpl_vars['t']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['t']->value) {
$_smarty_tpl->tpl_vars['t']->do_else = false;
?>
<tr><td><?php echo $_smarty_tpl->tpl_vars['t']->value['id_products'];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['t']->value['name'];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['t']->value['price'];?>
</td><!--edytuj lub usuń i dodaj 3 przyciski--><td><a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
editProducts/<?php echo $_smarty_tpl->tpl_vars['t']->value['id_products'];?>
"<span class="text-danger">Edytuj</span></a></td><td><a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
deleteProducts/<?php echo $_smarty_tpl->tpl_vars['t']->value['id_products'];?>
"<span class="text-danger">Usuń</span></a></td></tr>
<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>

<td><a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
addProducts/<?php echo $_smarty_tpl->tpl_vars['t']->value['id_products'];?>
"<span class="text-danger">Dodaj nowy produkt</span></a></td>

</tbody>
</table>
               
             
<?php
}
}
/* {/block 'content'} */
}
