<?php
/* Smarty version 4.1.0, created on 2022-05-29 20:31:18
  from 'C:\Users\Sony_PC\Desktop\xamp_\htdocs\piekarnia\app\views\Edit.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_6293bbf6d015d1_59758557',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '39bb0ae8c340a92afcafa7dbec58f09100ba2579' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\xamp_\\htdocs\\piekarnia\\app\\views\\Edit.tpl',
      1 => 1653848603,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6293bbf6d015d1_59758557 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_18724954556293bbf6cf7c16_25488426', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'content'} */
class Block_18724954556293bbf6cf7c16_25488426 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_18724954556293bbf6cf7c16_25488426',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>




<h1> Edycja: </h1>
               


<form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
editRole" method="post"  class="pure-form pure-form-aligned bottom-margin">
	
	<fieldset>
        <div class="pure-control-group">
			<label for="id_rola">rola: </label>
			<input id="id_rola" type="text" name="rola"/>
		</div>
       
		<div class="pure-controls">
			<input type="submit" value="zatwierdź" class="pure-button pure-button-primary"/>
		</div>
	</fieldset>
</form>	
               
             
<?php
}
}
/* {/block 'content'} */
}
