<?php
/* Smarty version 4.1.0, created on 2022-05-30 21:26:15
  from 'C:\Users\Sony_PC\Desktop\xamp_\htdocs\piekarnia\app\views\Summary.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_62951a572806d5_78230902',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a01e3aecb750cc8e92225ee32aca9336d69dc3bb' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\xamp_\\htdocs\\piekarnia\\app\\views\\Summary.tpl',
      1 => 1653938770,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62951a572806d5_78230902 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_37918654762951a5726ad28_33988352', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'content'} */
class Block_37918654762951a5726ad28_33988352 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_37918654762951a5726ad28_33988352',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>




<h1> Podsumowanie zamówienia: </h1>
               
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['dataSummary']->value, 't', false, 'v');
$_smarty_tpl->tpl_vars['t']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['v']->value => $_smarty_tpl->tpl_vars['t']->value) {
$_smarty_tpl->tpl_vars['t']->do_else = false;
?>
<tr><td><?php echo $_smarty_tpl->tpl_vars['v']->value;?>
</td><td><?php echo $_smarty_tpl->tpl_vars['t']->value['date_orders'];?>
</td>Id osoby zamawiającej<td><?php echo $_smarty_tpl->tpl_vars['t']->value['person_id_person'];?>
</td>Id nazwa<td><?php echo $_smarty_tpl->tpl_vars['t']->value['name'];?>
</td>Cena<td><?php echo $_smarty_tpl->tpl_vars['t']->value['price'];?>
</td>Ilość<td><?php echo $_smarty_tpl->tpl_vars['t']->value['quantity'];?>
</td><br></tr>   
<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
               
             
<?php
}
}
/* {/block 'content'} */
}
