<?php
/* Smarty version 4.1.0, created on 2022-05-31 10:20:44
  from 'C:\xampp\htdocs\piekarnia\app\views\EditView.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_6295cfdceb4c83_92415654',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd5b9aec8946c63325b7e5d92dbc2f40726090f3e' => 
    array (
      0 => 'C:\\xampp\\htdocs\\piekarnia\\app\\views\\EditView.tpl',
      1 => 1653860612,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6295cfdceb4c83_92415654 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_8178171626295cfdceb0548_06015453', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'content'} */
class Block_8178171626295cfdceb0548_06015453 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_8178171626295cfdceb0548_06015453',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>




<h1> Edycja: </h1>
               


<form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
editRole/<?php echo \core\ParamUtils::getFromCleanURL(1);?>
" method="post"  class="pure-form pure-form-aligned bottom-margin">
	
	<fieldset>
        <div class="pure-control-group">
			<label for="id_rola">rola: </label>
			<input id="id_rola" type="text" name="rola"/>                     
                      <!-- <input type="hidden" name="hidden_id" value="<?php echo \core\ParamUtils::getFromCleanURL(1);?>
" /> -->
		</div>
       
		<div class="pure-controls">
			<input type="submit" value="zatwierdź" class="pure-button pure-button-primary"/>
		</div>
	</fieldset>
</form>	
               
             
<?php
}
}
/* {/block 'content'} */
}
