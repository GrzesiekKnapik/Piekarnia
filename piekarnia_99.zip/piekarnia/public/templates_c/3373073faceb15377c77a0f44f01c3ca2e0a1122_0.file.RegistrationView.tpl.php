<?php
/* Smarty version 4.1.0, created on 2022-05-31 10:21:09
  from 'C:\xampp\htdocs\piekarnia\app\views\RegistrationView.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_6295cff5b43266_87666214',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3373073faceb15377c77a0f44f01c3ca2e0a1122' => 
    array (
      0 => 'C:\\xampp\\htdocs\\piekarnia\\app\\views\\RegistrationView.tpl',
      1 => 1653761744,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6295cff5b43266_87666214 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_6367113976295cff5b3e674_36512950', 'content');
?>


</html><?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'content'} */
class Block_6367113976295cff5b3e674_36512950 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_6367113976295cff5b3e674_36512950',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    
       
 <form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
registration" method="post"  class="pure-form pure-form-aligned bottom-margin">
	<legend>Rejestracja do systemu</legend>
	<fieldset>
        <div class="pure-control-group">
			<label for="id_name">Imie: </label>
			<input id="id_name" type="text"  placeholder="imie" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->name;?>
" name="name"/>
		</div>
        <div class="pure-control-group">
			<label for="id_surname">Nazwisko: </label>
			<input id="id_surname" type="text" placeholder="nazwisko" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->surname;?>
" name="surname" /><br />
		</div>
            <div class="pure-control-group">
			<label for="id_number">Login(Numer telefonu): </label>
			<input id="id_number" type="text" placeholder="numer telefonu" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->number;?>
" name="number" /><br />
		</div>
            <div class="pure-control-group">
			<label for="id_password">Hasło: </label>
			<input id="id_password" type="text" placeholder="haslo" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->password;?>
" name="password" /><br />
		</div>
            <div class="pure-control-group">
			<label for="id_password_re">Powtórz hasło: </label>
			<input id="id_password_re" type="text" placeholder="haslo" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->password_re;?>
"  name="password_re" /><br />
		</div>
		<div class="pure-controls">
			<input type="submit" value="ZAREJESTRUJ" class="pure-button pure-button-primary"/>
		</div>
	</fieldset>
</form>	

                
         
                
 

<?php
}
}
/* {/block 'content'} */
}
