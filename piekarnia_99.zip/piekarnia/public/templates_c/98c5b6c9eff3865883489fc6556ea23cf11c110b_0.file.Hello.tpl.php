<?php
/* Smarty version 4.1.0, created on 2022-06-07 10:53:45
  from 'C:\xampp\htdocs\piekarnia\app\views\Hello.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_629f1219c87851_69324804',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '98c5b6c9eff3865883489fc6556ea23cf11c110b' => 
    array (
      0 => 'C:\\xampp\\htdocs\\piekarnia\\app\\views\\Hello.tpl',
      1 => 1654557688,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_629f1219c87851_69324804 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


    

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_282060958629f1219c141e6_55331609', 'navigation');
?>





    
<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_957814251629f1219c15698_55854861', 'header');
?>
    
    
    
    
    
 

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_2135632104629f1219c15d45_48560010', 'content');
?>

</html>





</html>
    <?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main_1.tpl");
}
/* {block 'navigation'} */
class Block_282060958629f1219c141e6_55331609 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navigation' => 
  array (
    0 => 'Block_282060958629f1219c141e6_55331609',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container px-4 px-lg-5">
                <a class="navbar-brand" href="#!">Start Bootstrap</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                        
                        
                    </ul>
                    
                </div>
            </div>
        </nav>
<?php
}
}
/* {/block 'navigation'} */
/* {block 'header'} */
class Block_957814251629f1219c15698_55854861 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'header' => 
  array (
    0 => 'Block_957814251629f1219c15698_55854861',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<header class="bg-dark py-1">
            <div class="container px-4 px-lg-5 my-5">
                <div class="text-center text-white">
                    <h1 class="display-4 fw-bolder">Pod kłosem</h1>
                    <p class="lead fw-normal text-white-50 mb-0">Witamy w naszej piekarni.</p>
                    <p class="lead fw-normal text-white-50 mb-0">Prosimy się zalogować.</p>
                </div>
            </div>
        </header>
<?php
}
}
/* {/block 'header'} */
/* {block 'content'} */
class Block_2135632104629f1219c15d45_48560010 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_2135632104629f1219c15d45_48560010',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    
    

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Shop Homepage - Start Bootstrap Template</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Bootstrap icons-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body class="tlo">
        
       
        <section class="py-5 ">
  
            <div class="centrowanie">
       
            
            
            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class=" p btn-outline-dark mt-auto " href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
login" >Zaloguj</a></div>
                            </div>
            
                       
                  
        </div>
            
            
      
        </section>
        
        
     
    </body>
    <?php
}
}
/* {/block 'content'} */
}
