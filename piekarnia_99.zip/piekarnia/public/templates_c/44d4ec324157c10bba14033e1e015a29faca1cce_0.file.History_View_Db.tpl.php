<?php
/* Smarty version 4.1.0, created on 2022-06-07 01:15:58
  from 'C:\Users\Sony_PC\Desktop\xamp_\htdocs\piekarnia\app\views\History_View_Db.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_629e8aaed0ea92_42301978',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '44d4ec324157c10bba14033e1e015a29faca1cce' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\xamp_\\htdocs\\piekarnia\\app\\views\\History_View_Db.tpl',
      1 => 1654557352,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_629e8aaed0ea92_42301978 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1350773815629e8aaeceaf62_06649205', 'navigation');
?>




<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1843645207629e8aaecf8b92_87956220', 'header');
?>




<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_435761132629e8aaecf9d20_38975364', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "main_1.tpl");
}
/* {block 'navigation'} */
class Block_1350773815629e8aaeceaf62_06649205 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navigation' => 
  array (
    0 => 'Block_1350773815629e8aaeceaf62_06649205',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container px-4 px-lg-5">
                <a class="navbar-brand" href="#!">Start Bootstrap</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                        <li class="nav-item"><a class="nav-link active" aria-current="page" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
logout">Wyloguj</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
piekarnia">Piekarnia</a></li>
                        
                        <?php if (\core\RoleUtils::inRole("pracownik")) {?> 
                        <li class="nav-item"><a class="nav-link" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
dbProducts">Edycja produktów</a></li>
                        <?php }?>
                        
                    </ul>
                    
                </div>
            </div>
        </nav>
<?php
}
}
/* {/block 'navigation'} */
/* {block 'header'} */
class Block_1843645207629e8aaecf8b92_87956220 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'header' => 
  array (
    0 => 'Block_1843645207629e8aaecf8b92_87956220',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<header class="bg-dark py-1">
            <div class="container px-4 px-lg-5 my-5">
                <div class="text-center text-white">
                    <h1 class="display-4 fw-bolder">Pod kłosem</h1>
                    <p class="lead fw-normal text-white-50 mb-0">Historia.</p>

                </div>
            </div>
        </header>
<?php
}
}
/* {/block 'header'} */
/* {block 'content'} */
class Block_435761132629e8aaecf9d20_38975364 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_435761132629e8aaecf9d20_38975364',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>




<h1> Historia: </h1>

<table class="table background" style="width:40%"> 
  <thead>
    <tr>
      
      <th>Person_id</th>
                <th>Name</th>
                <th>Surname</th>
                <?php if (\core\RoleUtils::inRole("admin")) {?>
                <th>Number_login</th>
		<th>Role</th>
                <?php }?>
      
     
    </tr>
  </thead>
    
  <tbody>
      
      <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['data']->value, 't', false, 'v');
$_smarty_tpl->tpl_vars['t']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['v']->value => $_smarty_tpl->tpl_vars['t']->value) {
$_smarty_tpl->tpl_vars['t']->do_else = false;
?>
<tr><td><?php echo $_smarty_tpl->tpl_vars['t']->value['id_person'];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['t']->value['name'];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['t']->value['surname'];?>
</td><?php if (\core\RoleUtils::inRole("admin")) {?><td><?php echo $_smarty_tpl->tpl_vars['t']->value['number_login'];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['t']->value['role_id_role'];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['t']->value['type_role'];?>
</td><td><a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
editRole/<?php echo $_smarty_tpl->tpl_vars['t']->value['id_person'];?>
"<span class="text-danger">Edytuj</span></a></td><?php }?></tr>   
<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
   
    
  </tbody>
</table>

       
             
<?php
}
}
/* {/block 'content'} */
}
