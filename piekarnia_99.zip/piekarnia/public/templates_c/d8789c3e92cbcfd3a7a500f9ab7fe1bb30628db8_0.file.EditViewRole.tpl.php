<?php
/* Smarty version 4.1.0, created on 2022-06-07 01:29:08
  from 'C:\Users\Sony_PC\Desktop\xamp_\htdocs\piekarnia\app\views\EditViewRole.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_629e8dc477b789_42523183',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd8789c3e92cbcfd3a7a500f9ab7fe1bb30628db8' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\xamp_\\htdocs\\piekarnia\\app\\views\\EditViewRole.tpl',
      1 => 1654557681,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_629e8dc477b789_42523183 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>




<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_480773434629e8dc476ea29_85716409', 'navigation');
?>




<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_753835037629e8dc4776905_19168347', 'header');
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1569438027629e8dc4777a95_50230129', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "main_1.tpl");
}
/* {block 'navigation'} */
class Block_480773434629e8dc476ea29_85716409 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navigation' => 
  array (
    0 => 'Block_480773434629e8dc476ea29_85716409',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container px-4 px-lg-5">
                <a class="navbar-brand" href="#!">Start Bootstrap</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                        <li class="nav-item"><a class="nav-link active" aria-current="page" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
logout">Wyloguj</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
piekarnia">Piekarnia</a></li>
                        
                    </ul>
                    
                </div>
            </div>
        </nav>
<?php
}
}
/* {/block 'navigation'} */
/* {block 'header'} */
class Block_753835037629e8dc4776905_19168347 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'header' => 
  array (
    0 => 'Block_753835037629e8dc4776905_19168347',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<header class="bg-dark py-1">
            <div class="container px-4 px-lg-5 my-5">
                <div class="text-center text-white">
                    <h1 class="display-4 fw-bolder">Pod kłosem</h1>
                    <p class="lead fw-normal text-white-50 mb-0">Edycja roli.</p>

                </div>
            </div>
        </header>
<?php
}
}
/* {/block 'header'} */
/* {block 'content'} */
class Block_1569438027629e8dc4777a95_50230129 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_1569438027629e8dc4777a95_50230129',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>




<h1> Edycja: </h1>
               


<form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
editRole/<?php echo \core\ParamUtils::getFromCleanURL(1);?>
" method="post"  class="pure-form pure-form-aligned bottom-margin">
	
	<fieldset>
        <div class="pure-control-group">
			<label for="id_rola">rola: </label>
			<input id="id_rola" type="text" name="rola"/>                     
                      <!-- <input type="hidden" name="hidden_id" value="<?php echo \core\ParamUtils::getFromCleanURL(1);?>
" /> -->
		</div>
       
                
                <div class=" pt-0 border-top-0 bg-transparent offset-2">
    <input type="submit" value="zatwierdź" class="p-1 btn-outline-dark "/>
	</div>
		
	</fieldset>
</form>	
               
             
<?php
}
}
/* {/block 'content'} */
}
