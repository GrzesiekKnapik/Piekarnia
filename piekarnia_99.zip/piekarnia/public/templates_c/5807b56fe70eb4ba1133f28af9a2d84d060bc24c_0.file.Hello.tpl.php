<?php
/* Smarty version 4.1.0, created on 2022-06-07 01:21:33
  from 'C:\Users\Sony_PC\Desktop\xamp_\htdocs\piekarnia\app\views\Hello.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_629e8bfd602505_48126575',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5807b56fe70eb4ba1133f28af9a2d84d060bc24c' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\xamp_\\htdocs\\piekarnia\\app\\views\\Hello.tpl',
      1 => 1654557687,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_629e8bfd602505_48126575 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


    

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_297475342629e8bfd5f8fa8_98838675', 'navigation');
?>





    
<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1938850242629e8bfd5fa745_23271810', 'header');
?>
    
    
    
    
    
 

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1609684137629e8bfd5fb990_34685536', 'content');
?>

</html>





</html>
    <?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main_1.tpl");
}
/* {block 'navigation'} */
class Block_297475342629e8bfd5f8fa8_98838675 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navigation' => 
  array (
    0 => 'Block_297475342629e8bfd5f8fa8_98838675',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container px-4 px-lg-5">
                <a class="navbar-brand" href="#!">Start Bootstrap</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                        
                        
                    </ul>
                    
                </div>
            </div>
        </nav>
<?php
}
}
/* {/block 'navigation'} */
/* {block 'header'} */
class Block_1938850242629e8bfd5fa745_23271810 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'header' => 
  array (
    0 => 'Block_1938850242629e8bfd5fa745_23271810',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<header class="bg-dark py-1">
            <div class="container px-4 px-lg-5 my-5">
                <div class="text-center text-white">
                    <h1 class="display-4 fw-bolder">Pod kłosem</h1>
                    <p class="lead fw-normal text-white-50 mb-0">Witamy w naszej piekarni.</p>
                    <p class="lead fw-normal text-white-50 mb-0">Prosimy się zalogować.</p>
                </div>
            </div>
        </header>
<?php
}
}
/* {/block 'header'} */
/* {block 'content'} */
class Block_1609684137629e8bfd5fb990_34685536 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_1609684137629e8bfd5fb990_34685536',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    
    

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Shop Homepage - Start Bootstrap Template</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Bootstrap icons-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body class="tlo">
        
       
        <section class="py-5 ">
  
            <div class="centrowanie">
       
            
            
            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class=" p btn-outline-dark mt-auto " href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
login" >Zaloguj</a></div>
                            </div>
            
                       
                  
        </div>
            
            
      
        </section>
        
        
     
    </body>
    <?php
}
}
/* {/block 'content'} */
}
