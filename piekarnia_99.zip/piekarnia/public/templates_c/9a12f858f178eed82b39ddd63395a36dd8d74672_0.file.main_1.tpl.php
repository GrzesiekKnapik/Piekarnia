<?php
/* Smarty version 4.1.0, created on 2022-06-07 10:53:45
  from 'C:\xampp\htdocs\piekarnia\app\views\templates\main_1.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_629f1219ec7520_12273458',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9a12f858f178eed82b39ddd63395a36dd8d74672' => 
    array (
      0 => 'C:\\xampp\\htdocs\\piekarnia\\app\\views\\templates\\main_1.tpl',
      1 => 1654555710,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_629f1219ec7520_12273458 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>
<!doctype html>
<html lang="pl">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	
	<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        
        <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/css/styles.css">	
        
        <link rel="stylesheet" href="https://unpkg.com/purecss@0.6.2/build/pure-min.css" integrity="sha384-UQiGfs9ICog+LwheBSRCt1o5cbyKIHbwjWscjemyBMT9YCUMZffs6UqUTd0hObXD" crossorigin="anonymous">
        <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/css/style.css">	
        
</head>
<body>

<div class="navigation">
	<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1446678656629f1219db91e9_27312623', 'navigation');
?>

</div>    
    
    
    
<div class="header">
	<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1373281761629f1219db9a72_92506748', 'header');
?>

</div>

<div class="content">
<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1641632363629f1219dba186_00876593', 'content');
?>








<?php if ($_smarty_tpl->tpl_vars['msgs']->value->isMessage()) {?>

	
	<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getMessages(), 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
	<li class="msg <?php if ($_smarty_tpl->tpl_vars['msg']->value->isError()) {?>error<?php }?> <?php if ($_smarty_tpl->tpl_vars['msg']->value->isWarning()) {?>warning<?php }?> <?php if ($_smarty_tpl->tpl_vars['msg']->value->isInfo()) {?>info<?php }?>"><?php echo $_smarty_tpl->tpl_vars['msg']->value->text;?>
</li>
	<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
	
        &emsp;
<?php }?>







</div><!-- content -->

<?php if ($_smarty_tpl->tpl_vars['msgs']->value->isMessage() || !empty($_smarty_tpl->tpl_vars['shopping_cart']->value)) {?>
<div class="footer">
    <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_537080164629f1219ec2223_99038035', 'footer');
?>


</div>    
 <?php }?>  


<?php if (!$_smarty_tpl->tpl_vars['msgs']->value->isMessage() && empty($_smarty_tpl->tpl_vars['shopping_cart']->value)) {?>
<div class="footer na_dole">
    <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_683257201629f1219ec4bf7_90308545', 'footer');
?>


</div>    
 <?php }?>       

</body>
</html>

<?php }
/* {block 'navigation'} */
class Block_1446678656629f1219db91e9_27312623 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navigation' => 
  array (
    0 => 'Block_1446678656629f1219db91e9_27312623',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 Domyślna treść zawartości .... <?php
}
}
/* {/block 'navigation'} */
/* {block 'header'} */
class Block_1373281761629f1219db9a72_92506748 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'header' => 
  array (
    0 => 'Block_1373281761629f1219db9a72_92506748',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 Domyślna treść zawartości .... <?php
}
}
/* {/block 'header'} */
/* {block 'content'} */
class Block_1641632363629f1219dba186_00876593 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_1641632363629f1219dba186_00876593',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 Domyślna treść zawartości .... <?php
}
}
/* {/block 'content'} */
/* {block 'footer'} */
class Block_537080164629f1219ec2223_99038035 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_537080164629f1219ec2223_99038035',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 <footer class="py-5 bg-dark">
            <div class="container"><p class="m-0 text-center text-white">Copyright &copy; Your Website 2022</p></div>
        </footer> <?php
}
}
/* {/block 'footer'} */
/* {block 'footer'} */
class Block_683257201629f1219ec4bf7_90308545 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_683257201629f1219ec4bf7_90308545',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 <footer class="py-5 bg-dark">
            <div class="container"><p class="m-0 text-center text-white">Copyright &copy; Ja</p></div>
        </footer> <?php
}
}
/* {/block 'footer'} */
}
