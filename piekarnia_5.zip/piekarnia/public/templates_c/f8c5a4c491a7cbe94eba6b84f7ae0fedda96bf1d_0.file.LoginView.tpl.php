<?php
/* Smarty version 4.1.0, created on 2022-05-27 14:50:54
  from 'C:\Users\Sony_PC\Desktop\xamp_\htdocs\piekarnia\app\views\LoginView.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_6290c92eeb5949_88821294',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f8c5a4c491a7cbe94eba6b84f7ae0fedda96bf1d' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\xamp_\\htdocs\\piekarnia\\app\\views\\LoginView.tpl',
      1 => 1653655850,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6290c92eeb5949_88821294 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>





<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_3657748896290c92eead551_45637106', 'content');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'content'} */
class Block_3657748896290c92eead551_45637106 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_3657748896290c92eead551_45637106',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    

    
<form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
login" method="post"  class="pure-form pure-form-aligned bottom-margin">
	<legend>Logowanie do systemu</legend>
	<fieldset>
        <div class="pure-control-group">
			<label for="id_login">login(numer telefonu): </label>
			<input id="id_login" type="text" name="login"/>
		</div>
        <div class="pure-control-group">
			<label for="id_password">hasło: </label>
			<input id="id_password" type="password" name="password" /><br />
		</div>
		<div class="pure-controls">
			<input type="submit" value="zaloguj" class="pure-button pure-button-primary"/>
		</div>
	</fieldset>
</form>	

        <legend>Jesteś nowym klientem? Zarejestruj się</legend>
        
        
<div class="pure-menu pure-menu-horizontal bottom-margin">
	<a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
registration"  class="pure-menu-heading pure-menu-link">Rejestracja!</a>
</div>
        

<?php
}
}
/* {/block 'content'} */
}
