<?php
/* Smarty version 4.1.0, created on 2022-06-10 14:03:46
  from 'C:\Users\Sony_PC\Desktop\xamp_\htdocs\piekarnia\app\views\EditViewProductsAdd.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_62a33322a5c7f8_10557340',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd45898cafab9c6dcf7356f92a1e93a8872d5922c' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\xamp_\\htdocs\\piekarnia\\app\\views\\EditViewProductsAdd.tpl',
      1 => 1654858563,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62a33322a5c7f8_10557340 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_61384931962a33322a50820_16266224', 'navigation');
?>




<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_96685045162a33322a588c3_55708946', 'header');
?>





<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_188193169762a33322a59a55_87839656', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "main_1.tpl");
}
/* {block 'navigation'} */
class Block_61384931962a33322a50820_16266224 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navigation' => 
  array (
    0 => 'Block_61384931962a33322a50820_16266224',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container px-4 px-lg-5">
                <a class="navbar-brand" href="#!">Kłos</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                        <li class="nav-item"><a class="nav-link active" aria-current="page" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
logout">Wyloguj</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
piekarnia">Piekarnia</a></li>
                        
                    </ul>
                    
                </div>
            </div>
        </nav>
<?php
}
}
/* {/block 'navigation'} */
/* {block 'header'} */
class Block_96685045162a33322a588c3_55708946 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'header' => 
  array (
    0 => 'Block_96685045162a33322a588c3_55708946',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<header class="bg-dark py-1">
            <div class="container px-4 px-lg-5 my-5">
                <div class="text-center text-white">
                    <h1 class="display-4 fw-bolder">Pod kłosem</h1>
                    <p class="lead fw-normal text-white-50 mb-0">Dodawanie nowego produktu.</p>

                </div>
            </div>
        </header>
<?php
}
}
/* {/block 'header'} */
/* {block 'content'} */
class Block_188193169762a33322a59a55_87839656 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_188193169762a33322a59a55_87839656',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>




<h1> Edycja produktów: </h1>
               


<form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
addProducts" method="post"  class="pure-form pure-form-aligned bottom-margin">
	
	<fieldset>
        <div class="pure-control-group">
			<label for="id_nazwa">nazwa: </label>
			<input id="id_nazwa" type="text" name="nazwa"/>                     
                      <!-- <input type="hidden" name="hidden_id" value="<?php echo \core\ParamUtils::getFromCleanURL(1);?>
" /> -->
                        <label for="id_cena">cena: </label>
			<input id="id_cena" type="text" name="cena"/>
                       
		</div>
       
		<div class=" pt-0 border-top-0 bg-transparent offset-2">
    <input type="submit" value="zatwierdź" class="p-1 btn-outline-dark "/>
	</div>
	</fieldset>
</form>	
                        
                        
                        
                        
                        
                        
               
             
<?php
}
}
/* {/block 'content'} */
}
