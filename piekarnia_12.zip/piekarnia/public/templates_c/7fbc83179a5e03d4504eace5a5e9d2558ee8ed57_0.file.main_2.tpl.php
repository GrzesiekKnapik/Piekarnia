<?php
/* Smarty version 4.1.0, created on 2022-06-10 12:52:36
  from 'C:\Users\Sony_PC\Desktop\xamp_\htdocs\piekarnia\app\views\templates\main_2.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_62a322743ec3b0_02927683',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7fbc83179a5e03d4504eace5a5e9d2558ee8ed57' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\xamp_\\htdocs\\piekarnia\\app\\views\\templates\\main_2.tpl',
      1 => 1654858313,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62a322743ec3b0_02927683 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>
<!doctype html>
<html lang="pl">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	
	<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        
        <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/css/styles.css">	
        
        <link rel="stylesheet" href="https://unpkg.com/purecss@0.6.2/build/pure-min.css" integrity="sha384-UQiGfs9ICog+LwheBSRCt1o5cbyKIHbwjWscjemyBMT9YCUMZffs6UqUTd0hObXD" crossorigin="anonymous">
        <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/css/style.css">	
        
</head>
<body>

<div class="navigation">
	<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_122234564762a322743d6d20_20867952', 'navigation');
?>

</div>    
    
    
    
<div class="header">
	<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_128391107162a322743d81e7_16526980', 'header');
?>

</div>

<div class="content ogólny">
<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_164164041962a322743d93a0_97905871', 'content');
?>








<?php if ($_smarty_tpl->tpl_vars['msgs']->value->isMessage()) {?>

	
	<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getMessages(), 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
	<li class="msg <?php if ($_smarty_tpl->tpl_vars['msg']->value->isError()) {?>error<?php }?> <?php if ($_smarty_tpl->tpl_vars['msg']->value->isWarning()) {?>warning<?php }?> <?php if ($_smarty_tpl->tpl_vars['msg']->value->isInfo()) {?>info<?php }?>"><?php echo $_smarty_tpl->tpl_vars['msg']->value->text;?>
</li>
	<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
	
        &emsp;
<?php }?>







</div><!-- content -->


<div class="footer">
    <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_49303627162a322743e9a68_80620279', 'footer');
?>


</div>    

   

</body>
</html>

<?php }
/* {block 'navigation'} */
class Block_122234564762a322743d6d20_20867952 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navigation' => 
  array (
    0 => 'Block_122234564762a322743d6d20_20867952',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 Domyślna treść zawartości .... <?php
}
}
/* {/block 'navigation'} */
/* {block 'header'} */
class Block_128391107162a322743d81e7_16526980 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'header' => 
  array (
    0 => 'Block_128391107162a322743d81e7_16526980',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 Domyślna treść zawartości .... <?php
}
}
/* {/block 'header'} */
/* {block 'content'} */
class Block_164164041962a322743d93a0_97905871 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_164164041962a322743d93a0_97905871',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 Domyślna treść zawartości .... <?php
}
}
/* {/block 'content'} */
/* {block 'footer'} */
class Block_49303627162a322743e9a68_80620279 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_49303627162a322743e9a68_80620279',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 <footer class="py-5 bg-dark">
            <div class="container"><p class="m-0 text-center text-white">Copyright &copy; Grzegorz Knapik</p></div>
        </footer> <?php
}
}
/* {/block 'footer'} */
}
