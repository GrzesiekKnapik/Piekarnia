<?php
/* Smarty version 4.1.0, created on 2022-05-23 18:04:55
  from 'C:\Users\Sony_PC\Desktop\xamp_\htdocs\piekarnia\app\views\Hello.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_628bb0a7a27502_00809589',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5807b56fe70eb4ba1133f28af9a2d84d060bc24c' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\xamp_\\htdocs\\piekarnia\\app\\views\\Hello.tpl',
      1 => 1652358258,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_628bb0a7a27502_00809589 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<!DOCTYPE HTML>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="pl" lang="pl">

<head>
	<meta charset="utf-8"/>
	<title>Hello World | Amelia framework</title>
</head>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1963523504628bb0a7a1e024_13212634', 'content');
?>



</html>
    <?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main_1.tpl");
}
/* {block 'content'} */
class Block_1963523504628bb0a7a1e024_13212634 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_1963523504628bb0a7a1e024_13212634',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    
    
<h2>Witamy w naszej piekarni pod kłosem!</h2>  
<h3>Prosimy o zalogowanie się!</h3> 


<div class="pure-menu pure-menu-horizontal bottom-margin">
	<a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
login"  class="pure-menu-heading pure-menu-link">Zaloguj się</a>
    
         
	
</div>

<?php
}
}
/* {/block 'content'} */
}
