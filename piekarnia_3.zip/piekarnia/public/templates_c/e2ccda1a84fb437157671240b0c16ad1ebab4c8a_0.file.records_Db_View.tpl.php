<?php
/* Smarty version 4.1.0, created on 2022-05-27 15:05:09
  from 'C:\Users\Sony_PC\Desktop\xamp_\htdocs\piekarnia\app\views\templates\records_Db_View.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_6290cc85b56615_38333976',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e2ccda1a84fb437157671240b0c16ad1ebab4c8a' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\xamp_\\htdocs\\piekarnia\\app\\views\\templates\\records_Db_View.tpl',
      1 => 1653656692,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6290cc85b56615_38333976 (Smarty_Internal_Template $_smarty_tpl) {
?><table>
<thead>
	<tr>
		
		<th>Numer</th>
		
       
	
	</tr>
</thead>
<tbody>
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['data']->value, 't');
$_smarty_tpl->tpl_vars['t']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['t']->value) {
$_smarty_tpl->tpl_vars['t']->do_else = false;
?>
<tr><td><?php echo $_smarty_tpl->tpl_vars['t']->value['number'];?>
</td></tr>
<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
</tbody>
</table><?php }
}
