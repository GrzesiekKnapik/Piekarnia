<?php


namespace app\controllers;

use core\App;
use core\Message;
use core\Utils;
use core\SessionUtils;
use core\RoleUtils;
use core\ParamUtils;

//


class Piekarnia {
    
    private $total = 0;
    
   
       //mam tutaj rzeczy z sesji ktore chce wyświetlić w tpl 
      
       //echo SessionUtils::loadObject('user',true)->id_user;
       //tylko tym sposobem sie tego nie da zrobić chyba
       
       
        public function show_products(){
        $data_items = App::getDB()->select("products", [
            "Id",
            "name",
            "price",
        ]);
       App::getSmarty()->assign('data_items', $data_items);
        } 
        
        
        
        ///////////////////////////////////////////////////
        public function shopping_card(){
          
       if((ParamUtils::getFromRequest('add_to_cart', $required = true)))  
       {
          
           if(isset($_SESSION["shopping_cart"]))  
           {  
               //w tablicy klika tablic i wyswietlany z tych kilku tylko item_id, badamy tylko item_id ile wynoszą
               //potem zeby sprawdzic czy juz jest dodana jakas opcja a ją znowu kliknelismy, jezeli nie ma to dodajemy do koszyka
           $item_array_id = array_column($_SESSION["shopping_cart"], "item_id");  
           if(!in_array(ParamUtils::getFromRequest('hidden_id'), $item_array_id))  
           {  
                //$count = count($_SESSION["shopping_cart"]);  
            
                $item_array = array(  
                     'item_id'               =>    ParamUtils::getFromRequest('hidden_id'),  
                     'item_name'               =>     ParamUtils::getFromRequest('hidden_name'),  
                     'item_price'          =>     ParamUtils::getFromRequest('hidden_price'),  
                     'item_quantity'          =>    ParamUtils::getFromRequest('quantity')  
                );  
                $_SESSION["shopping_cart"][] = $item_array; 
             
                Utils::addInfoMessage('Dodano nowy produkt');
                
           }  
           else  
           {  
               
              // if(in_array(ParamUtils::getFromRequest('hidden_id'), $item_array_id))
           // {
                //foreach($_SESSION["shopping_cart"] as $keys => $values)
               // {
                //     $_SESSION["shopping_cart"][$keys]["item_quantity"] = $_SESSION["shopping_cart"][$keys]["item_quantity"]+ParamUtils::getFromRequest('quantity') ;
                // }                 
            // }
               
               Utils::addErrorMessage('Taki produkt został już dodany');
               //redirecta tu 
                 
           }  
      }  
      else  
      {  
           $item_array = array(  
                'item_id'               =>     ParamUtils::getFromRequest('hidden_id'),  
                'item_name'               =>    ParamUtils::getFromRequest('hidden_name'),    
                'item_price'          =>     ParamUtils::getFromRequest('hidden_price'),  
                'item_quantity'          =>     ParamUtils::getFromRequest('quantity')    
           );  
           $_SESSION["shopping_cart"][] = $item_array;  
          
      }  
       
      if(!empty($_SESSION["shopping_cart"])){
       foreach ($_SESSION["shopping_cart"] as $t)
    {
        
        $this->total = $this->total + ($t["item_quantity"] * $t["item_price"]);  
        
    }
      App::getSmarty()->assign('shopping_cart', $_SESSION["shopping_cart"]);
    }
    
        }
        }
        
    
     
     
        
        
        
        
        
    public function action_piekarnia(){       
        $this->show_products();       
        $this->shopping_card();  
        $this->generateView();       
    }
    
    
    public function generateView() {       
    App::getSmarty()->assign('page_title', 'Zakupy w piekarni');    
    App::getSmarty()->assign('total', $this->total);   
    App::getSmarty()->display("Piekarnia.tpl");
    }

    
   
    
   
   // $a = SessionUtils::loadObject('user',true)->login;
   // App::getSmarty()->assign('sesjaa', $a);
   
    
     public function action_delete(){
         $total = 0;
         $zmienna = 0;
         $zmienna = ParamUtils::getFromCleanURL(1);
                //$keys to indeksowanie tablicy czyli zawsze 0,1,2,3... a $value to wartości czyli 312...  [0] = 3, [1] = 1, [2] = 2,   echo$keys  echovaleus[item_id]
              foreach($_SESSION["shopping_cart"] as $keys => $values)  
             {                  
                      if($values['item_id']==$zmienna)
                      {
                                 
                       unset($_SESSION["shopping_cart"][$keys]); 
                      
                      }      
                  
                
              }
             App::getRouter()->forwardTo("piekarnia");
      
 }   
 

 
 
       
     
        
        
      
        
    }
    
   
       



