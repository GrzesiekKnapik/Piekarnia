<?php

namespace app\controllers;

use core\App;
use core\Utils;
use core\RoleUtils;
use core\ParamUtils;
use app\forms\LoginForm;


class DbHistory
{
//zmienic na private te funkcje jedną!

 
     
    public function action_sie()
    {
       
  
        # wywołanie obiektu Medoo
      //echo'efaefa';
      
        $data = App::getDB()->select("person", [
            "id_person",
            "name",
            "surname",
            "number_login",
            "password",
            
        ]);
       App::getSmarty()->assign('data', $data);
         $this->generateView();
        
    }
       
        
    

   

   
    public function generateView()
    {
       // getSmarty()->assign('user', unserialize($_SESSION['user']));
       
      
        App::getSmarty()->assign('page_title', 'Historia');
        App::getSmarty()->display('History_View_Db.tpl');
    }
}